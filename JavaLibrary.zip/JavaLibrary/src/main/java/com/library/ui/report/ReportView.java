package com.library.ui.report;

import com.jfoenix.controls.*;
import com.library.model.Book;
import com.library.service.*;
import com.library.util.ExportUtil;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;

import java.io.File;
import java.util.List;

/**
 * 统计报表视图 —— 柱状图、饼图及导出按钮
 */
public class ReportView extends BorderPane {
    private final ReportService reportService;
    private final BookService bookService;
    private final BorrowService borrowService;
    private final NotificationService notificationService;

    public ReportView(ReportService reportService, BookService bookService,
                      BorrowService borrowService, NotificationService notificationService) {
        this.reportService = reportService;
        this.bookService = bookService;
        this.borrowService = borrowService;
        this.notificationService = notificationService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(10));

        VBox mainPanel = new VBox(15);
        mainPanel.setPadding(new Insets(5));

        Label title = new Label("统计报表");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 20));
        title.setTextFill(Color.valueOf("#2c3e50"));

        // 总罚款
        double totalFines = reportService.getTotalFines();
        HBox summaryRow = new HBox(20);
        summaryRow.getChildren().add(createStatCard("总罚款", String.format("%.1f 元", totalFines)));

        // 图表切换
        HBox chartSwitch = new HBox(15);
        chartSwitch.setAlignment(Pos.CENTER_LEFT);
        JFXButton pieBtn = new JFXButton("分类借阅占比（饼图）");
        pieBtn.getStyleClass().addAll("jfx-button", "primary");
        JFXButton barBtn = new JFXButton("热门图书排行（柱状图）");
        barBtn.getStyleClass().addAll("jfx-button", "primary");
        chartSwitch.getChildren().addAll(pieBtn, barBtn);

        // 图表容器
        StackPane chartContainer = new StackPane();
        chartContainer.setPrefHeight(400);
        chartContainer.getStyleClass().add("card");

        pieBtn.setOnAction(e -> chartContainer.getChildren().setAll(createPieChart()));
        barBtn.setOnAction(e -> chartContainer.getChildren().setAll(createBarChart()));
        chartContainer.getChildren().add(createPieChart()); // 默认显示饼图

        // 导出按钮
        HBox exportRow = new HBox(12);
        exportRow.setAlignment(Pos.CENTER_LEFT);
        JFXButton exportBooksBtn = new JFXButton("导出图书列表");
        exportBooksBtn.getStyleClass().addAll("jfx-button", "success");
        FontAwesomeIconView excelIcon = new FontAwesomeIconView(FontAwesomeIcon.FILE_EXCEL_ALT);
        excelIcon.setSize("16");
        exportBooksBtn.setGraphic(excelIcon);
        exportBooksBtn.setOnAction(e -> exportBooks());

        JFXButton exportRecordsBtn = new JFXButton("导出借阅记录");
        exportRecordsBtn.getStyleClass().addAll("jfx-button", "success");
        exportRecordsBtn.setGraphic(new FontAwesomeIconView(FontAwesomeIcon.FILE_EXCEL_ALT));
        exportRecordsBtn.setOnAction(e -> exportRecords());

        JFXButton exportFinesBtn = new JFXButton("导出罚款明细");
        exportFinesBtn.getStyleClass().addAll("jfx-button", "warning");
        exportFinesBtn.setGraphic(new FontAwesomeIconView(FontAwesomeIcon.FILE_EXCEL_ALT));
        exportFinesBtn.setOnAction(e -> exportFines());

        exportRow.getChildren().addAll(exportBooksBtn, exportRecordsBtn, exportFinesBtn);

        mainPanel.getChildren().addAll(title, summaryRow, chartSwitch, chartContainer, exportRow);
        setCenter(mainPanel);
    }

    private PieChart createPieChart() {
        PieChart pieChart = new PieChart();
        pieChart.setTitle("各分类借阅占比");
        List<Object[]> stats = reportService.getCategoryStats();
        for (Object[] stat : stats) {
            String name = (String) stat[0];
            int count = (Integer) stat[1];
            pieChart.getData().add(new PieChart.Data(name, count));
        }
        pieChart.setLabelsVisible(true);
        return pieChart;
    }

    private BarChart<String, Number> createBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("图书");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("借阅次数");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("热门图书借阅排行");
        List<Object[]> stats = reportService.getHotBookStats(10);
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("借阅次数");
        for (Object[] stat : stats) {
            String name = ((String) stat[0]);
            // 截断过长书名
            if (name.length() > 12) name = name.substring(0, 12) + "...";
            series.getData().add(new XYChart.Data<>(name, (Integer) stat[1]));
        }
        barChart.getData().add(series);
        return barChart;
    }

    private VBox createStatCard(String label, String value) {
        VBox card = new VBox(8);
        card.getStyleClass().add("stat-card");
        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font(24));
        valueLabel.setTextFill(Color.valueOf("#e74c3c"));
        Label labelLbl = new Label(label);
        labelLbl.setFont(Font.font(13));
        card.getChildren().addAll(valueLabel, labelLbl);
        return card;
    }

    private void exportBooks() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("导出图书列表");
        chooser.setInitialFileName("图书列表.xlsx");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel文件", "*.xlsx"));
        File file = chooser.showSaveDialog(getScene().getWindow());
        if (file != null) {
            try {
                ExportUtil.exportBooks(bookService.getAllBooks(), file);
                showInfo("导出成功", "图书列表已导出到: " + file.getAbsolutePath());
            } catch (Exception e) {
                showError("导出失败: " + e.getMessage());
            }
        }
    }

    private void exportRecords() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("导出借阅记录");
        chooser.setInitialFileName("借阅记录.xlsx");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel文件", "*.xlsx"));
        File file = chooser.showSaveDialog(getScene().getWindow());
        if (file != null) {
            try {
                ExportUtil.exportBorrowRecords(borrowService.getAllRecords(), file);
                showInfo("导出成功", "借阅记录已导出到: " + file.getAbsolutePath());
            } catch (Exception e) {
                showError("导出失败: " + e.getMessage());
            }
        }
    }

    private void exportFines() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("导出罚款明细");
        chooser.setInitialFileName("罚款明细.xlsx");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel文件", "*.xlsx"));
        File file = chooser.showSaveDialog(getScene().getWindow());
        if (file != null) {
            try {
                ExportUtil.exportFineDetails(borrowService.getAllRecords(), file);
                showInfo("导出成功", "罚款明细已导出到: " + file.getAbsolutePath());
            } catch (Exception e) {
                showError("导出失败: " + e.getMessage());
            }
        }
    }

    private void showInfo(String title, String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }

    private void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }
}
