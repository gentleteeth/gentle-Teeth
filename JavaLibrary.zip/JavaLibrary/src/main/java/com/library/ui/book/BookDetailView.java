package com.library.ui.book;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.*;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.List;

/**
 * 图书详情视图 —— 展示图书信息、评分、评论
 */
public class BookDetailView extends BorderPane {
    private final Book book;
    private final BookService bookService;
    private final ReviewService reviewService;
    private final BorrowService borrowService;
    private final ReservationService reservationService;
    private final UserService userService;
    private final NotificationService notificationService;

    public BookDetailView(Book book, BookService bookService, ReviewService reviewService,
                          BorrowService borrowService, ReservationService reservationService,
                          UserService userService, NotificationService notificationService) {
        this.book = book;
        this.bookService = bookService;
        this.reviewService = reviewService;
        this.borrowService = borrowService;
        this.reservationService = reservationService;
        this.userService = userService;
        this.notificationService = notificationService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(16));

        HBox mainRow = new HBox(20);

        // 左侧：图书信息卡片
        VBox infoCard = new VBox(15);
        infoCard.getStyleClass().add("card");
        infoCard.setPrefWidth(400);

        Label titleLabel = new Label(book.getTitle());
        titleLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 22));
        titleLabel.setWrapText(true);

        GridPane infoGrid = new GridPane();
        infoGrid.setHgap(10);
        infoGrid.setVgap(8);
        int row = 0;
        addInfoRow(infoGrid, row++, "ISBN", book.getIsbn());
        addInfoRow(infoGrid, row++, "作者", book.getAuthor());
        addInfoRow(infoGrid, row++, "出版社", book.getPublisher());
        addInfoRow(infoGrid, row++, "分类", book.getCategoryName());
        addInfoRow(infoGrid, row++, "出版年份", String.valueOf(book.getPublishYear()));
        addInfoRow(infoGrid, row++, "馆藏位置", book.getLocation());
        addInfoRow(infoGrid, row++, "库存", book.getAvailableCopies() + " / " + book.getTotalCopies());
        addInfoRow(infoGrid, row++, "简介", book.getDescription() != null ? book.getDescription() : "暂无简介");

        // 平均评分
        double avgRating = reviewService.getAverageRating(book.getId());
        HBox ratingBox = new HBox(5);
        ratingBox.setAlignment(Pos.CENTER_LEFT);
        Label ratingLabel = new Label("评分：");
        ratingLabel.setFont(Font.font(13));
        ratingBox.getChildren().add(ratingLabel);
        for (int i = 1; i <= 5; i++) {
            Label star = new Label(i <= Math.round(avgRating) ? "★" : "☆");
            star.setStyle("-fx-font-size: 20px; -fx-text-fill: " + (i <= Math.round(avgRating) ? "#f39c12" : "#bdc3c7") + ";");
            ratingBox.getChildren().add(star);
        }
        Label avgLabel = new Label("(" + avgRating + "分)");
        avgLabel.setFont(Font.font(12));
        avgLabel.setTextFill(Color.valueOf("#7f8c8d"));
        ratingBox.getChildren().add(avgLabel);

        // 操作按钮
        HBox actionButtons = new HBox(10);
        User currentUser = userService.getCurrentUser();

        JFXButton borrowBtn = new JFXButton("借阅此书");
        borrowBtn.getStyleClass().addAll("jfx-button", "primary");
        borrowBtn.setOnAction(e -> handleBorrow());

        JFXButton reserveBtn = new JFXButton("预约此书");
        reserveBtn.getStyleClass().addAll("jfx-button", "warning");
        reserveBtn.setOnAction(e -> handleReserve());

        if (currentUser instanceof Member) {
            actionButtons.getChildren().addAll(borrowBtn, reserveBtn);
        }

        infoCard.getChildren().addAll(titleLabel, new Separator(), infoGrid, ratingBox, actionButtons);

        // 右侧：评论区域
        VBox reviewSection = new VBox(12);
        reviewSection.setPrefWidth(450);

        Label reviewTitle = new Label("读者评论");
        reviewTitle.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));

        // 发表评论
        VBox addReviewBox = new VBox(8);
        addReviewBox.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 6; -fx-padding: 12;");
        Label addReviewLabel = new Label("发表评论");
        addReviewLabel.setFont(Font.font(13));

        HBox starSelect = new HBox(5);
        starSelect.setAlignment(Pos.CENTER_LEFT);
        Label[] stars = new Label[5];
        int[] selectedRating = {0};
        for (int i = 0; i < 5; i++) {
            final int rating = i + 1;
            stars[i] = new Label("☆");
            stars[i].setStyle("-fx-font-size: 22px; -fx-cursor: hand;");
            int idx = i;
            stars[i].setOnMouseClicked(ev -> {
                selectedRating[0] = rating;
                for (int j = 0; j < 5; j++) {
                    stars[j].setText(j < rating ? "★" : "☆");
                    stars[j].setStyle("-fx-font-size: 22px; -fx-text-fill: " + (j < rating ? "#f39c12" : "#bdc3c7") + "; -fx-cursor: hand;");
                }
            });
            starSelect.getChildren().add(stars[i]);
        }

        JFXTextArea commentArea = new JFXTextArea();
        commentArea.setPromptText("写下你的评论...");
        commentArea.setPrefRowCount(2);

        JFXButton submitBtn = new JFXButton("提交评论");
        submitBtn.getStyleClass().addAll("jfx-button", "primary");
        submitBtn.setOnAction(e -> {
            if (selectedRating[0] == 0) {
                showAlert("请先选择评分"); return;
            }
            String result = reviewService.addReview(currentUser, book.getId(),
                    selectedRating[0], commentArea.getText().trim());
            if (result.equals("评论发表成功")) {
                commentArea.clear();
                selectedRating[0] = 0;
                for (Label star : stars) { star.setText("☆"); star.setStyle("-fx-font-size: 22px; -fx-text-fill: #bdc3c7; -fx-cursor: hand;"); }
                refreshReviews(reviewSection);
            } else {
                showAlert(result);
            }
        });

        addReviewBox.getChildren().addAll(addReviewLabel, starSelect, commentArea, submitBtn);

        // 评论列表
        VBox reviewList = new VBox(8);
        refreshReviews(reviewList);

        reviewSection.getChildren().addAll(reviewTitle, addReviewBox, reviewList);

        mainRow.getChildren().addAll(infoCard, reviewSection);
        HBox.setHgrow(reviewSection, Priority.ALWAYS);

        // 返回按钮
        JFXButton backBtn = new JFXButton("← 返回");
        backBtn.getStyleClass().add("jfx-button");
        backBtn.setOnAction(e -> {
            // 返回图书列表 - 通过父容器处理
            getChildren().clear();
            // 使用导航方式
        });

        VBox topBox = new VBox(10, backBtn, mainRow);
        setCenter(topBox);
    }

    private void refreshReviews(VBox reviewList) {
        reviewList.getChildren().clear();
        List<Review> reviews = reviewService.getBookReviews(book.getId());
        if (reviews.isEmpty()) {
            reviewList.getChildren().add(new Label("暂无评论"));
        } else {
            for (Review r : reviews) {
                VBox reviewCard = new VBox(5);
                reviewCard.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 6; -fx-padding: 10;");
                HBox header = new HBox(10);
                header.setAlignment(Pos.CENTER_LEFT);
                Label userLabel = new Label(r.getUsername());
                userLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 12));
                String starStr = "★".repeat(r.getRating()) + "☆".repeat(5 - r.getRating());
                Label starLabel = new Label(starStr);
                starLabel.setStyle("-fx-text-fill: #f39c12;");
                header.getChildren().addAll(userLabel, starLabel);

                Label commentLabel = new Label(r.getComment());
                commentLabel.setWrapText(true);
                commentLabel.setFont(Font.font(12));

                Label dateLabel = new Label(r.getCreatedAt() != null ? r.getCreatedAt().toString().substring(0, 16) : "");
                dateLabel.setFont(Font.font(10));
                dateLabel.setTextFill(Color.valueOf("#95a5a6"));

                reviewCard.getChildren().addAll(header, commentLabel, dateLabel);
                reviewList.getChildren().add(reviewCard);
            }
        }
    }

    private void handleBorrow() {
        User user = userService.getCurrentUser();
        String result = borrowService.borrowBook(user, book);
        if ("SUCCESS".equals(result)) {
            showInfo("借阅成功", "《" + book.getTitle() + "》借阅成功！");
        } else {
            showAlert(result);
        }
    }

    private void handleReserve() {
        User user = userService.getCurrentUser();
        String result = reservationService.reserveBook(user, book.getId());
        showInfo("预约", result);
    }

    private void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lbl = new Label(label + "：");
        lbl.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 13));
        grid.add(lbl, 0, row);
        Label val = new Label(value != null ? value : "-");
        val.setFont(Font.font(13));
        val.setWrapText(true);
        val.setMaxWidth(280);
        grid.add(val, 1, row);
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING, msg);
        alert.showAndWait();
    }

    private void showInfo(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.setTitle(title);
        alert.showAndWait();
    }
}
