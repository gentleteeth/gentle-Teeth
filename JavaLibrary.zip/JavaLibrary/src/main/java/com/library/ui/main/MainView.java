package com.library.ui.main;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.*;
import com.library.ui.book.*;
import com.library.ui.borrow.*;
import com.library.ui.login.LoginView;
import com.library.ui.report.ReportView;
import com.library.ui.setting.SettingView;
import com.library.ui.user.*;
import com.library.util.*;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * 主界面 —— 侧边导航抽屉 + 内容区域
 */
public class MainView {
    private final Stage stage;
    private final UserService userService;
    private final BookService bookService;
    private final NotificationService notificationService;
    private final BorrowService borrowService;
    private final ReservationService reservationService;
    private final ReviewService reviewService;
    private final ReportService reportService;
    private final RecommendationService recommendationService;
    private final BackupService backupService;

    private BorderPane mainLayout;
    private StackPane contentArea;
    private VBox sidebar;
    private Label userInfoLabel;
    private Label notificationLabel;
    private HBox notificationBar;
    private boolean sidebarExpanded = true;

    public MainView(Stage stage, UserService userService) {
        this.stage = stage;
        this.userService = userService;

        // 初始化所有服务
        this.bookService = new BookService();
        this.notificationService = new NotificationService();
        this.borrowService = new BorrowService(bookService, notificationService);
        this.reservationService = new ReservationService(bookService, notificationService);
        this.borrowService.setReservationService(reservationService); // 注入预约服务，使还书后能通知预约用户
        this.reviewService = new ReviewService(borrowService);
        this.reportService = new ReportService();
        this.recommendationService = new RecommendationService();
        this.backupService = new BackupService();

        // 注册库存观察者（将在各视图中注册）
        setupNotificationListener();
    }

    public void show() {
        mainLayout = new BorderPane();

        // 顶部栏
        mainLayout.setTop(createHeader());

        // 侧边栏
        sidebar = createSidebar();
        mainLayout.setLeft(sidebar);

        // 底部通知栏
        notificationBar = createNotificationBar();
        notificationBar.setVisible(false);
        notificationBar.setManaged(false);
        mainLayout.setBottom(notificationBar);

        // 内容区域
        contentArea = new StackPane();
        contentArea.setPadding(new Insets(16));
        showDefaultView();
        mainLayout.setCenter(contentArea);

        Scene scene = new Scene(mainLayout, 1200, 750);
        applyTheme(scene);

        stage.setTitle("图书管理系统 - " + userService.getCurrentUser().getRoleDisplayName());
        stage.setScene(scene);
        stage.setMinWidth(1000);
        stage.setMinHeight(650);
        stage.centerOnScreen();
        stage.show();
    }

    /** 顶部栏 */
    private HBox createHeader() {
        HBox header = new HBox(15);
        header.getStyleClass().add("header-bar");
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(8, 20, 8, 20));

        // 折叠按钮
        JFXButton toggleBtn = new JFXButton();
        FontAwesomeIconView barsIcon = new FontAwesomeIconView(FontAwesomeIcon.BARS);
        barsIcon.setSize("18");
        barsIcon.setFill(Color.valueOf("#ecf0f1"));
        toggleBtn.setGraphic(barsIcon);
        toggleBtn.setStyle("-fx-background-color: transparent;");
        toggleBtn.setOnAction(e -> toggleSidebar());

        // Logo与标题
        FontAwesomeIconView bookIcon = new FontAwesomeIconView(FontAwesomeIcon.BOOK);
        bookIcon.setSize("22");
        bookIcon.setFill(Color.valueOf("#3498db"));
        Label titleLabel = new Label("图书管理系统");
        titleLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 18));
        titleLabel.setTextFill(Color.valueOf("#ecf0f1"));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // 用户信息
        User currentUser = userService.getCurrentUser();
        userInfoLabel = new Label();
        FontAwesomeIconView userIcon = new FontAwesomeIconView(FontAwesomeIcon.USER);
        userIcon.setSize("16");
        userIcon.setFill(Color.valueOf("#bdc3c7"));

        HBox userBox = new HBox(8, userIcon, userInfoLabel);
        userBox.setAlignment(Pos.CENTER_RIGHT);
        updateUserInfo();

        // 退出按钮
        JFXButton logoutBtn = new JFXButton("退出");
        logoutBtn.setStyle("-fx-background-color: #c0392b; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 6 14 6 14;");
        logoutBtn.setOnAction(e -> logout());

        header.getChildren().addAll(toggleBtn, bookIcon, titleLabel, spacer, userBox, logoutBtn);
        return header;
    }

    /** 侧边导航栏 */
    private VBox createSidebar() {
        VBox nav = new VBox(5);
        nav.getStyleClass().add("sidebar");
        nav.setPrefWidth(240);
        nav.setMinWidth(240);
        nav.setPadding(new Insets(10, 0, 10, 0));

        User user = userService.getCurrentUser();

        // 首页（所有角色可见）
        addNavButton(nav, "首页", FontAwesomeIcon.HOME, () -> showDefaultView());

        // 图书管理（admin、librarian）
        if (user instanceof Admin || user instanceof Librarian) {
            addNavButton(nav, "图书管理", FontAwesomeIcon.BOOK, () -> showView(new BookManagementView(
                    bookService, userService, this::showView, this::showBookDetail, this::showBookDialog)));
        }

        // 借书管理（admin、librarian）
        if (user instanceof Admin || user instanceof Librarian) {
            addNavButton(nav, "借书管理", FontAwesomeIcon.SIGN_IN,
                    () -> showView(new BorrowView(bookService, borrowService, userService, notificationService)));
        }

        // 还书管理（admin、librarian）
        if (user instanceof Admin || user instanceof Librarian) {
            addNavButton(nav, "还书管理", FontAwesomeIcon.SIGN_OUT,
                    () -> showView(new ReturnView(borrowService, bookService)));
        }

        // 我的借阅（member）
        if (user instanceof Member) {
            addNavButton(nav, "图书浏览", FontAwesomeIcon.SEARCH,
                    () -> showView(new BookManagementView(bookService, userService, this::showView, this::showBookDetail, this::showBookDialog)));
            addNavButton(nav, "我的借阅", FontAwesomeIcon.LIST_ALT,
                    () -> showView(new com.library.ui.borrow.BorrowView(bookService, borrowService, userService, notificationService)));
        }

        // 读者管理（admin）
        if (user instanceof Admin) {
            addNavButton(nav, "读者管理", FontAwesomeIcon.USERS,
                    () -> showView(new UserManagementView(userService)));
        }

        // 统计报表（admin、librarian）
        if (user instanceof Admin || user instanceof Librarian) {
            addNavButton(nav, "统计报表", FontAwesomeIcon.BAR_CHART,
                    () -> showView(new ReportView(reportService, bookService, borrowService, notificationService)));
        }

        // 系统设置
        addNavButton(nav, "系统设置", FontAwesomeIcon.COG,
                () -> showView(new SettingView(bookService, backupService)));

        // 下方填充
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        nav.getChildren().add(spacer);

        // 版本信息
        Label versionLabel = new Label("v1.0.0");
        versionLabel.setTextFill(Color.valueOf("#7f8c8d"));
        versionLabel.setFont(Font.font(11));
        versionLabel.setPadding(new Insets(10, 20, 10, 20));
        nav.getChildren().add(versionLabel);

        return nav;
    }

    private void addNavButton(VBox nav, String text, FontAwesomeIcon icon, Runnable action) {
        JFXButton btn = new JFXButton("  " + text);
        FontAwesomeIconView iconView = new FontAwesomeIconView(icon);
        iconView.setSize("16");
        btn.setGraphic(iconView);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setOnAction(e -> action.run());
        nav.getChildren().add(btn);
    }

    /** 底部通知栏 */
    private HBox createNotificationBar() {
        HBox bar = new HBox(12);
        bar.getStyleClass().addAll("notification-bar", "info");
        bar.setAlignment(Pos.CENTER_LEFT);

        FontAwesomeIconView bellIcon = new FontAwesomeIconView(FontAwesomeIcon.BELL);
        bellIcon.setSize("14");
        bellIcon.setFill(Color.valueOf("#ecf0f1"));

        notificationLabel = new Label();
        notificationLabel.setTextFill(Color.valueOf("#ecf0f1"));
        notificationLabel.setFont(Font.font(13));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        JFXButton closeBtn = new JFXButton("×");
        closeBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #ecf0f1; -fx-font-size: 16px;");
        closeBtn.setOnAction(e -> {
            notificationBar.setVisible(false);
            notificationBar.setManaged(false);
        });

        bar.getChildren().addAll(bellIcon, notificationLabel, spacer, closeBtn);
        return bar;
    }

    /** 显示默认视图 */
    private void showDefaultView() {
        VBox home = new VBox(20);
        home.setPadding(new Insets(10));

        // 欢迎卡片
        VBox welcomeCard = new VBox(12);
        welcomeCard.getStyleClass().add("card");
        Label welcomeLabel = new Label("欢迎使用图书管理系统");
        welcomeLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 22));
        welcomeLabel.setTextFill(Color.valueOf("#2c3e50"));
        Label roleLabel = new Label("当前角色：" + userService.getCurrentUser().getRoleDisplayName());
        roleLabel.setFont(Font.font(14));
        roleLabel.setTextFill(Color.valueOf("#7f8c8d"));
        welcomeCard.getChildren().addAll(welcomeLabel, roleLabel);

        // 统计卡片行
        HBox statsRow = new HBox(20);
        statsRow.getChildren().addAll(
                createStatCard("图书总数", String.valueOf(bookService.getTotalBookCount()), FontAwesomeIcon.BOOK),
                createStatCard("当前借出", String.valueOf(borrowService.getCurrentBorrows().size()), FontAwesomeIcon.EXCHANGE),
                createStatCard("用户总数", String.valueOf(userService.getAllUsers().size()), FontAwesomeIcon.USERS)
        );

        // 推荐图书区域（仅member角色显示）
        VBox recommendSection = null;
        if (userService.getCurrentUser() instanceof Member) {
            recommendSection = new VBox(12);
            recommendSection.setPadding(new Insets(10, 0, 0, 0));
            Label recTitle = new Label("为您推荐");
            recTitle.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));
            recTitle.setTextFill(Color.valueOf("#2c3e50"));

            FlowPane recCards = new FlowPane(15, 15);
            var recommendations = recommendationService.recommendForUser(
                    userService.getCurrentUser().getId(), 6);
            for (RecommendedBookDecorator decorator : recommendations) {
                recCards.getChildren().add(createRecommendCard(decorator));
            }
            if (recommendations.isEmpty()) {
                recCards.getChildren().add(new Label("暂无推荐数据，多借几本书试试吧~"));
            }
            recommendSection.getChildren().addAll(recTitle, recCards);
        }

        home.getChildren().addAll(welcomeCard, statsRow);
        if (recommendSection != null) home.getChildren().add(recommendSection);

        contentArea.getChildren().clear();
        ScrollPane scrollPane = new ScrollPane(home);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");
        contentArea.getChildren().add(scrollPane);
    }

    private VBox createStatCard(String label, String value, FontAwesomeIcon icon) {
        VBox card = new VBox(8);
        card.getStyleClass().add("stat-card");
        FontAwesomeIconView iconView = new FontAwesomeIconView(icon);
        iconView.setSize("24");
        iconView.setFill(Color.valueOf("#3498db"));
        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("stat-number");
        Label labelLbl = new Label(label);
        labelLbl.getStyleClass().add("stat-label");
        card.getChildren().addAll(iconView, valueLabel, labelLbl);
        return card;
    }

    private VBox createRecommendCard(RecommendedBookDecorator decorator) {
        VBox card = new VBox(8);
        card.getStyleClass().add("card");
        card.setPrefWidth(200);
        card.setMaxWidth(200);

        Label tagLabel = new Label("推荐");
        tagLabel.getStyleClass().add("tag");

        Label titleLabel = new Label(decorator.getBook().getTitle());
        titleLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 14));
        titleLabel.setWrapText(true);

        Label authorLabel = new Label(decorator.getBook().getAuthor());
        authorLabel.setFont(Font.font(12));
        authorLabel.setTextFill(Color.valueOf("#7f8c8d"));

        Label reasonLabel = new Label(decorator.getExtraInfo());
        reasonLabel.setFont(Font.font(11));
        reasonLabel.setTextFill(Color.valueOf("#e67e22"));
        reasonLabel.setWrapText(true);

        card.getChildren().addAll(tagLabel, titleLabel, authorLabel, reasonLabel);
        return card;
    }

    /** 切换到指定视图 */
    public void showView(Region view) {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(view);
    }

    /** 显示图书详情 */
    private void showBookDetail(Book book) {
        showView(new BookDetailView(book, bookService, reviewService, borrowService,
                reservationService, userService, notificationService));
    }

    /** 显示图书编辑对话框 */
    private void showBookDialog(Book book) {
        if (book == null) {
            BookDialog dialog = new BookDialog(bookService, null, this::showView,
                    this::showBookDetail, this::showBookDialog);
            dialog.showAndWait().ifPresent(b -> showDefaultView());
        }
    }

    /** 设置通知监听 */
    private void setupNotificationListener() {
        notificationService.setListener(notification -> {
            if (notification.userId == userService.getCurrentUser().getId()) {
                Platform.runLater(() -> showNotification(notification.message, notification.type));
            }
        });
    }

    private void showNotification(String message, String type) {
        notificationLabel.setText(message);
        notificationBar.getStyleClass().removeAll("success", "warning", "error", "info");
        notificationBar.getStyleClass().add(type != null ? type : "info");
        notificationBar.setVisible(true);
        notificationBar.setManaged(true);
        // 5秒后自动隐藏
        new Thread(() -> {
            try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
            Platform.runLater(() -> {
                notificationBar.setVisible(false);
                notificationBar.setManaged(false);
            });
        }).start();
    }

    /** 折叠/展开侧边栏 */
    private void toggleSidebar() {
        sidebarExpanded = !sidebarExpanded;
        if (sidebarExpanded) {
            sidebar.setPrefWidth(240);
            sidebar.setMinWidth(240);
            sidebar.setVisible(true);
            sidebar.setManaged(true);
        } else {
            sidebar.setPrefWidth(0);
            sidebar.setMinWidth(0);
            sidebar.setVisible(false);
            sidebar.setManaged(false);
        }
    }

    /** 更新用户信息显示 */
    private void updateUserInfo() {
        User user = userService.getCurrentUser();
        userInfoLabel.setText(user.getUsername() + " (" + user.getRoleDisplayName() + ")");
        userInfoLabel.setTextFill(Color.valueOf("#ecf0f1"));
        userInfoLabel.setFont(Font.font(13));
    }

    /** 退出登录 */
    private void logout() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "确定要退出登录吗？");
        confirm.setTitle("退出确认");
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                userService.logout();
                new LoginView(stage, userService).show();
            }
        });
    }

    private void applyTheme(Scene scene) {
        String theme = ThemeManager.getInstance().getCurrentThemePath();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource(theme).toExternalForm());
    }
}
