package com.library.ui.book;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.*;
import com.library.util.*;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.List;
import java.util.function.Consumer;

/**
 * 图书管理视图 —— TableView + 搜索栏 + 操作按钮
 */
public class BookManagementView extends BorderPane implements InventoryObserver {

    private final BookService bookService;
    private final UserService userService;
    private final Consumer<Region> navigator;
    private final Consumer<Book> detailViewer;
    private final Consumer<Book> dialogShower;
    private TableView<Book> tableView;
    private JFXTextField searchField;
    private JFXComboBox<String> searchTypeCombo;
    private JFXComboBox<Category> categoryCombo;
    private Label pageLabel;
    private int currentPage = 1;
    private static final int PAGE_SIZE = 10;
    private List<Book> allBooks;

    public BookManagementView(BookService bookService, UserService userService,
                              Consumer<Region> navigator, Consumer<Book> detailViewer,
                              Consumer<Book> dialogShower) {
        this.bookService = bookService;
        this.userService = userService;
        this.navigator = navigator;
        this.detailViewer = detailViewer;
        this.dialogShower = dialogShower;
        bookService.addObserver(this);
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(10));
        // 顶部标题
        Label title = new Label("图书管理");
        title.setFont(Font.font("Microsoft YaHei", javafx.scene.text.FontWeight.BOLD, 20));
        title.setTextFill(Color.valueOf("#2c3e50"));
        title.setPadding(new Insets(0, 0, 12, 0));

        // 搜索栏
        HBox searchBar = createSearchBar();

        // 表格
        tableView = createTable();

        // 分页栏
        HBox paginationBar = createPaginationBar();

        VBox mainContent = new VBox(10, title, searchBar, tableView, paginationBar);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        setCenter(mainContent);
    }

    private HBox createSearchBar() {
        HBox bar = new HBox(12);
        bar.getStyleClass().add("search-bar");
        bar.setAlignment(Pos.CENTER_LEFT);

        searchField = new JFXTextField();
        searchField.setPromptText("输入搜索关键词...");
        searchField.setPrefWidth(250);
        searchField.setOnAction(e -> doSearch());

        searchTypeCombo = new JFXComboBox<>();
        searchTypeCombo.getItems().addAll("全部", "书名", "作者", "ISBN");
        searchTypeCombo.getSelectionModel().select(0);
        searchTypeCombo.setPrefWidth(100);

        categoryCombo = new JFXComboBox<>();
        categoryCombo.getItems().add(new Category(0, "全部分类", ""));
        categoryCombo.getItems().addAll(bookService.getAllCategories());
        categoryCombo.getSelectionModel().select(0);
        categoryCombo.setPrefWidth(140);
        categoryCombo.setConverter(new javafx.util.StringConverter<Category>() {
            @Override public String toString(Category c) { return c != null ? c.getName() : ""; }
            @Override public Category fromString(String s) { return null; }
        });

        JFXButton searchBtn = new JFXButton("搜索");
        searchBtn.getStyleClass().addAll("jfx-button", "primary");
        FontAwesomeIconView searchIcon = new FontAwesomeIconView(FontAwesomeIcon.SEARCH);
        searchIcon.setSize("14");
        searchBtn.setGraphic(searchIcon);
        searchBtn.setOnAction(e -> doSearch());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        JFXButton addBtn = new JFXButton("添加图书");
        addBtn.getStyleClass().addAll("jfx-button", "success");
        FontAwesomeIconView plusIcon = new FontAwesomeIconView(FontAwesomeIcon.PLUS);
        plusIcon.setSize("14");
        addBtn.setGraphic(plusIcon);
        addBtn.setOnAction(e -> {
            BookDialog dialog = new BookDialog(bookService, null, navigator, detailViewer, dialogShower);
            dialog.showAndWait().ifPresent(b -> refreshTable());
        });

        bar.getChildren().addAll(searchField, searchTypeCombo, categoryCombo, searchBtn, spacer, addBtn);
        return bar;
    }

    @SuppressWarnings("unchecked")
    private TableView<Book> createTable() {
        TableView<Book> table = new TableView<>();
        table.getStyleClass().add("table-view");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Book, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);

        TableColumn<Book, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        isbnCol.setPrefWidth(120);

        TableColumn<Book, String> titleCol = new TableColumn<>("书名");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleCol.setPrefWidth(200);

        TableColumn<Book, String> authorCol = new TableColumn<>("作者");
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorCol.setPrefWidth(120);

        TableColumn<Book, String> catCol = new TableColumn<>("分类");
        catCol.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        catCol.setPrefWidth(100);

        TableColumn<Book, Integer> availCol = new TableColumn<>("可借/总册");
        availCol.setPrefWidth(80);
        availCol.setCellValueFactory(new PropertyValueFactory<>("availableCopies"));
        availCol.setCellFactory(col -> new TableCell<Book, Integer>() {
            @Override protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) {
                    setText(null);
                } else {
                    Book b = getTableRow().getItem();
                    setText(b.getAvailableCopies() + "/" + b.getTotalCopies());
                    setTextFill(b.getAvailableCopies() == 0 ? Color.RED : Color.GREEN);
                }
            }
        });

        TableColumn<Book, String> locCol = new TableColumn<>("位置");
        locCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        locCol.setPrefWidth(100);

        TableColumn<Book, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(200);
        actionCol.setCellFactory(col -> new TableCell<Book, Void>() {
            private final JFXButton detailBtn = new JFXButton("详情");
            private final JFXButton editBtn = new JFXButton("编辑");
            private final JFXButton deleteBtn = new JFXButton("删除");
            private final HBox box = new HBox(8);
            {
                detailBtn.getStyleClass().addAll("jfx-button", "primary");
                detailBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                editBtn.getStyleClass().addAll("jfx-button", "warning");
                editBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                deleteBtn.getStyleClass().addAll("jfx-button", "danger");
                deleteBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                box.setAlignment(Pos.CENTER);
                box.getChildren().addAll(detailBtn, editBtn, deleteBtn);
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); }
                else {
                    Book b = getTableRow().getItem();
                    detailBtn.setOnAction(e -> detailViewer.accept(b));
                    editBtn.setOnAction(e -> {
                        BookDialog dialog = new BookDialog(bookService, b, navigator, detailViewer, dialogShower);
                        dialog.showAndWait().ifPresent(bb -> refreshTable());
                    });
                    boolean isAdminOrLib = userService.getCurrentUser() instanceof Admin ||
                            userService.getCurrentUser() instanceof Librarian;
                    editBtn.setVisible(isAdminOrLib);
                    deleteBtn.setVisible(isAdminOrLib);
                    deleteBtn.setOnAction(e -> {
                        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "确定删除《" + b.getTitle() + "》吗？");
                        confirm.setTitle("删除确认");
                        confirm.showAndWait().ifPresent(r -> {
                            if (r == ButtonType.OK) {
                                bookService.deleteBook(b.getId());
                                refreshTable();
                            }
                        });
                    });
                    setGraphic(box);
                }
            }
        });

        table.getColumns().addAll(idCol, isbnCol, titleCol, authorCol, catCol, availCol, locCol, actionCol);
        table.setRowFactory(tv -> {
            TableRow<Book> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty()) {
                    detailViewer.accept(row.getItem());
                }
            });
            return row;
        });

        refreshTable();
        return table;
    }

    private HBox createPaginationBar() {
        HBox bar = new HBox(15);
        bar.getStyleClass().add("pagination-bar");
        bar.setAlignment(Pos.CENTER);

        JFXButton prevBtn = new JFXButton("上一页");
        prevBtn.getStyleClass().add("jfx-button");
        prevBtn.setOnAction(e -> { if (currentPage > 1) { currentPage--; refreshPage(); } });

        pageLabel = new Label("第 1 页");
        pageLabel.setFont(Font.font(13));

        JFXButton nextBtn = new JFXButton("下一页");
        nextBtn.getStyleClass().add("jfx-button");
        nextBtn.setOnAction(e -> {
            int total = (allBooks != null ? allBooks.size() : 0);
            if (currentPage * PAGE_SIZE < total) { currentPage++; refreshPage(); }
        });

        bar.getChildren().addAll(prevBtn, pageLabel, nextBtn);
        return bar;
    }

    private void doSearch() {
        currentPage = 1;
        String keyword = searchField.getText().trim();
        Category cat = categoryCombo.getValue();
        Integer catId = (cat != null && cat.getId() > 0) ? cat.getId() : null;
        String searchType = switch (searchTypeCombo.getSelectionModel().getSelectedIndex()) {
            case 1 -> "title"; case 2 -> "author"; case 3 -> "isbn"; default -> "all";
        };
        allBooks = bookService.searchBooks(keyword, catId, searchType);
        refreshPage();
    }

    private void refreshTable() {
        currentPage = 1;
        allBooks = bookService.getAllBooks();
        refreshPage();
    }

    private void refreshPage() {
        if (allBooks == null) allBooks = bookService.getAllBooks();
        int from = (currentPage - 1) * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, allBooks.size());
        ObservableList<Book> pageData = FXCollections.observableArrayList(allBooks.subList(from, to));
        tableView.setItems(pageData);
        int totalPages = (int) Math.ceil((double) allBooks.size() / PAGE_SIZE);
        pageLabel.setText("第 " + currentPage + "/" + Math.max(1, totalPages) + " 页 (共" + allBooks.size() + "条)");
    }

    @Override
    public void onInventoryChanged() {
        refreshTable();
    }
}
