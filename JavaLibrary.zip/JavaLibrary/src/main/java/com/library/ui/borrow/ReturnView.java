package com.library.ui.borrow;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.*;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * 还书管理视图
 */
public class ReturnView extends BorderPane {
    private final BorrowService borrowService;
    private final BookService bookService;

    private TableView<BorrowRecord> tableView;
    private JFXTextField isbnField;
    private Label infoLabel;

    public ReturnView(BorrowService borrowService, BookService bookService) {
        this.borrowService = borrowService;
        this.bookService = bookService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(10));

        VBox mainPanel = new VBox(12);

        Label title = new Label("还书管理");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 20));
        title.setTextFill(Color.valueOf("#2c3e50"));

        // ISBN快捷还书
        HBox quickReturn = new HBox(12);
        quickReturn.setAlignment(Pos.CENTER_LEFT);
        quickReturn.getStyleClass().add("search-bar");

        isbnField = new JFXTextField();
        isbnField.setPromptText("输入ISBN快速还书...");
        isbnField.setPrefWidth(250);

        JFXButton quickReturnBtn = new JFXButton("一键还书");
        quickReturnBtn.getStyleClass().addAll("jfx-button", "success");
        FontAwesomeIconView checkIcon = new FontAwesomeIconView(FontAwesomeIcon.CHECK);
        checkIcon.setSize("14");
        quickReturnBtn.setGraphic(checkIcon);
        quickReturnBtn.setOnAction(e -> quickReturn());

        infoLabel = new Label();
        infoLabel.setFont(Font.font(13));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        JFXButton refreshBtn = new JFXButton("刷新列表");
        refreshBtn.getStyleClass().addAll("jfx-button", "primary");
        refreshBtn.setOnAction(e -> refreshTable());

        quickReturn.getChildren().addAll(isbnField, quickReturnBtn, infoLabel, spacer, refreshBtn);

        // 借出列表
        tableView = createTable();
        VBox.setVgrow(tableView, Priority.ALWAYS);

        mainPanel.getChildren().addAll(title, quickReturn, tableView);
        setCenter(mainPanel);
    }

    @SuppressWarnings("unchecked")
    private TableView<BorrowRecord> createTable() {
        TableView<BorrowRecord> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<BorrowRecord, Integer> idCol = new TableColumn<>("记录ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(60);

        TableColumn<BorrowRecord, String> userCol = new TableColumn<>("借阅人");
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        userCol.setPrefWidth(100);

        TableColumn<BorrowRecord, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("bookIsbn"));
        isbnCol.setPrefWidth(110);

        TableColumn<BorrowRecord, String> bookCol = new TableColumn<>("书名");
        bookCol.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        bookCol.setPrefWidth(200);

        TableColumn<BorrowRecord, String> borrowCol = new TableColumn<>("借阅日期");
        borrowCol.setCellValueFactory(cell -> {
            var d = cell.getValue().getBorrowDate();
            return new javafx.beans.property.SimpleStringProperty(
                    d != null ? d.toLocalDate().toString() : "");
        });

        TableColumn<BorrowRecord, String> dueCol = new TableColumn<>("应还日期");
        dueCol.setCellValueFactory(cell -> {
            var d = cell.getValue().getDueDate();
            return new javafx.beans.property.SimpleStringProperty(
                    d != null ? d.toLocalDate().toString() : "");
        });

        TableColumn<BorrowRecord, String> statusCol = new TableColumn<>("状态");
        statusCol.setCellValueFactory(cell -> {
            return new javafx.beans.property.SimpleStringProperty(
                    cell.getValue().isOverdue() ? "已逾期" : "借阅中");
        });
        statusCol.setCellFactory(col -> new TableCell<BorrowRecord, String>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setText(null);
                else {
                    setText(item);
                    setTextFill("已逾期".equals(item) ? Color.RED : Color.GREEN);
                }
            }
        });

        TableColumn<BorrowRecord, String> fineCol = new TableColumn<>("逾期罚款");
        fineCol.setCellValueFactory(cell -> {
            return new javafx.beans.property.SimpleStringProperty(
                    String.format("%.1f元", cell.getValue().calculateFine()));
        });

        TableColumn<BorrowRecord, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(100);
        actionCol.setCellFactory(col -> new TableCell<BorrowRecord, Void>() {
            private final JFXButton returnBtn = new JFXButton("还书");
            {
                returnBtn.getStyleClass().addAll("jfx-button", "success");
                returnBtn.setStyle("-fx-padding: 4 14 4 14;");
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); }
                else {
                    BorrowRecord r = getTableRow().getItem();
                    returnBtn.setOnAction(e -> {
                        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                                "确定归还《" + r.getBookTitle() + "》？\n罚款金额：" +
                                        String.format("%.1f", r.calculateFine()) + "元");
                        confirm.setTitle("还书确认");
                        confirm.showAndWait().ifPresent(ans -> {
                            if (ans == ButtonType.OK) {
                                String result = borrowService.returnBook(r.getId());
                                infoLabel.setText(result);
                                refreshTable();
                            }
                        });
                    });
                    setGraphic(returnBtn);
                }
            }
        });

        table.getColumns().addAll(idCol, userCol, isbnCol, bookCol, borrowCol, dueCol, statusCol, fineCol, actionCol);
        refreshTableData(table);
        return table;
    }

    private void quickReturn() {
        String isbn = isbnField.getText().trim();
        if (isbn.isEmpty()) {
            infoLabel.setText("请输入ISBN");
            infoLabel.setTextFill(Color.RED);
            return;
        }

        // 查找该ISBN的当前借阅记录
        var records = borrowService.getCurrentBorrows();
        var match = records.stream()
                .filter(r -> isbn.equals(r.getBookIsbn()))
                .findFirst();

        if (match.isPresent()) {
            BorrowRecord r = match.get();
            double fine = r.calculateFine();
            String result = borrowService.returnBook(r.getId());
            infoLabel.setText(result);
            if (fine > 0) {
                infoLabel.setText(infoLabel.getText() + " (罚款: " + String.format("%.1f", fine) + "元)");
            }
            infoLabel.setTextFill(Color.GREEN);
            isbnField.clear();
            refreshTable();
        } else {
            infoLabel.setText("未找到该ISBN对应的借阅记录");
            infoLabel.setTextFill(Color.RED);
        }
    }

    private void refreshTable() {
        refreshTableData(tableView);
    }

    private void refreshTableData(TableView<BorrowRecord> table) {
        table.setItems(FXCollections.observableArrayList(borrowService.getCurrentBorrows()));
    }
}
