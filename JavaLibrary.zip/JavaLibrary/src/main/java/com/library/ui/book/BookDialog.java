package com.library.ui.book;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.BookService;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.Optional;
import java.util.function.Consumer;

/**
 * 图书添加/编辑对话框
 */
public class BookDialog {
    private final BookService bookService;
    private final Book existingBook;
    private final Consumer<Region> navigator;
    private final Consumer<Book> detailViewer;
    private final Consumer<Book> dialogShower;
    private Dialog<Book> dialog;

    private JFXTextField isbnField, titleField, authorField, publisherField;
    private JFXTextField yearField, totalField, locationField;
    private JFXComboBox<Category> categoryCombo;
    private JFXTextArea descArea;

    public BookDialog(BookService bookService, Book existingBook, Consumer<Region> navigator,
                      Consumer<Book> detailViewer, Consumer<Book> dialogShower) {
        this.bookService = bookService;
        this.existingBook = existingBook;
        this.navigator = navigator;
        this.detailViewer = detailViewer;
        this.dialogShower = dialogShower;
    }

    public Optional<Book> showAndWait() {
        dialog = new Dialog<>();
        dialog.setTitle(existingBook == null ? "添加图书" : "编辑图书");
        dialog.setHeaderText(null);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));
        grid.setMinWidth(550);

        int row = 0;

        isbnField = createField(grid, "ISBN：", row++);
        titleField = createField(grid, "书名：", row++);
        authorField = createField(grid, "作者：", row++);
        publisherField = createField(grid, "出版社：", row++);

        // 分类下拉
        grid.add(new Label("分类："), 0, row);
        categoryCombo = new JFXComboBox<>();
        categoryCombo.setPrefWidth(300);
        categoryCombo.getItems().addAll(bookService.getAllCategories());
        categoryCombo.setConverter(new javafx.util.StringConverter<Category>() {
            @Override public String toString(Category c) { return c != null ? c.getName() : ""; }
            @Override public Category fromString(String s) { return null; }
        });
        grid.add(categoryCombo, 1, row++);

        yearField = createField(grid, "出版年份：", row++);
        totalField = createField(grid, "总册数：", row++);
        locationField = createField(grid, "馆藏位置：", row++);

        grid.add(new Label("简介："), 0, row);
        descArea = new JFXTextArea();
        descArea.setPrefRowCount(3);
        descArea.setPrefWidth(300);
        grid.add(descArea, 1, row++);

        // 填充已有数据
        if (existingBook != null) {
            isbnField.setText(existingBook.getIsbn());
            titleField.setText(existingBook.getTitle());
            authorField.setText(existingBook.getAuthor());
            publisherField.setText(existingBook.getPublisher());
            yearField.setText(String.valueOf(existingBook.getPublishYear()));
            totalField.setText(String.valueOf(existingBook.getTotalCopies()));
            locationField.setText(existingBook.getLocation());
            descArea.setText(existingBook.getDescription());
            if (existingBook.getCategoryId() > 0) {
                for (Category c : categoryCombo.getItems()) {
                    if (c.getId() == existingBook.getCategoryId()) {
                        categoryCombo.setValue(c);
                        break;
                    }
                }
            }
        }

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStyleClass().add("dialog-container");

        ButtonType saveBtnType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtnType, ButtonType.CANCEL);

        Button saveBtn = (Button) dialog.getDialogPane().lookupButton(saveBtnType);
        saveBtn.addEventFilter(javafx.event.ActionEvent.ACTION, e -> {
            if (!validateAndSave()) e.consume();
        });

        dialog.setResultConverter(btn -> btn == saveBtnType ? buildBook() : null);
        return dialog.showAndWait();
    }

    private JFXTextField createField(GridPane grid, String label, int row) {
        Label lbl = new Label(label);
        lbl.setFont(Font.font(13));
        grid.add(lbl, 0, row);
        JFXTextField field = new JFXTextField();
        field.setPrefWidth(300);
        grid.add(field, 1, row);
        return field;
    }

    private boolean validateAndSave() {
        String title = titleField.getText().trim();
        if (title.isEmpty()) {
            showAlert("书名不能为空"); return false;
        }
        String isbn = isbnField.getText().trim();
        if (existingBook == null && !isbn.isEmpty()) {
            Book exist = bookService.getBookByIsbn(isbn);
            if (exist != null) {
                showAlert("ISBN已存在"); return false;
            }
        }
        try {
            int year = Integer.parseInt(yearField.getText().trim());
            if (year < 1000 || year > 2100) { showAlert("出版年份不合法"); return false; }
        } catch (NumberFormatException e) {
            if (!yearField.getText().trim().isEmpty()) { showAlert("出版年份必须为数字"); return false; }
        }
        try {
            int total = Integer.parseInt(totalField.getText().trim());
            if (total < 1) { showAlert("总册数至少为1"); return false; }
        } catch (NumberFormatException e) {
            if (!totalField.getText().trim().isEmpty()) { showAlert("总册数必须为数字"); return false; }
        }
        return true;
    }

    private Book buildBook() {
        Book book = existingBook != null ? existingBook : new Book();
        book.setIsbn(isbnField.getText().trim());
        book.setTitle(titleField.getText().trim());
        book.setAuthor(authorField.getText().trim());
        book.setPublisher(publisherField.getText().trim());
        Category cat = categoryCombo.getValue();
        if (cat != null) book.setCategoryId(cat.getId());
        try { book.setPublishYear(Integer.parseInt(yearField.getText().trim())); } catch (Exception ignored) {}
        try {
            int total = Integer.parseInt(totalField.getText().trim());
            book.setTotalCopies(total);
            if (existingBook == null) book.setAvailableCopies(total);
        } catch (Exception ignored) {}
        book.setLocation(locationField.getText().trim());
        book.setDescription(descArea.getText() != null ? descArea.getText().trim() : "");
        return book;
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING, msg);
        alert.showAndWait();
    }
}
