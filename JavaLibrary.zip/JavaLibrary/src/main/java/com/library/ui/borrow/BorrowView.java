package com.library.ui.borrow;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.*;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.List;

/**
 * 借书管理视图
 */
public class BorrowView extends BorderPane {
    private final BookService bookService;
    private final BorrowService borrowService;
    private final UserService userService;
    private final NotificationService notificationService;

    private JFXTextField searchBookField;
    private JFXTextField userIdField;
    private JFXTextField isbnField;
    private TableView<Book> bookTable;
    private TableView<BorrowRecord> recordTable;
    private Label statusLabel;

    public BorrowView(BookService bookService, BorrowService borrowService,
                      UserService userService, NotificationService notificationService) {
        this.bookService = bookService;
        this.borrowService = borrowService;
        this.userService = userService;
        this.notificationService = notificationService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(10));

        TabPane tabPane = new TabPane();

        // Tab1: 借书
        Tab borrowTab = new Tab("借书");
        borrowTab.setContent(createBorrowPanel());
        borrowTab.setClosable(false);

        // Tab2: 当前借阅
        Tab currentTab = new Tab("当前借阅");
        currentTab.setContent(createCurrentBorrowPanel());
        currentTab.setClosable(false);

        tabPane.getTabs().addAll(borrowTab, currentTab);
        setCenter(tabPane);
    }

    private VBox createBorrowPanel() {
        VBox panel = new VBox(15);
        panel.setPadding(new Insets(10));

        // 搜索区域
        HBox searchRow = new HBox(12);
        searchRow.setAlignment(Pos.CENTER_LEFT);
        searchRow.getStyleClass().add("search-bar");

        searchBookField = new JFXTextField();
        searchBookField.setPromptText("输入书名搜索...");
        searchBookField.setPrefWidth(250);

        JFXButton searchBtn = new JFXButton("搜索");
        searchBtn.getStyleClass().addAll("jfx-button", "primary");
        searchBtn.setOnAction(e -> searchBooks());

        isbnField = new JFXTextField();
        isbnField.setPromptText("或扫描ISBN");
        isbnField.setPrefWidth(150);
        isbnField.setOnAction(e -> searchByIsbn());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // 用户选择
        Label userLabel = new Label("读者ID：");
        userIdField = new JFXTextField();
        User currentUser = userService.getCurrentUser();
        if (currentUser instanceof Member) {
            userIdField.setText(String.valueOf(currentUser.getId()));
            userIdField.setEditable(false);
        } else {
            userIdField.setPromptText("输入读者ID");
            userIdField.setPrefWidth(80);
        }

        searchRow.getChildren().addAll(searchBookField, searchBtn, isbnField, spacer,
                userLabel, userIdField);
        panel.getChildren().add(searchRow);

        // 图书表格
        bookTable = createBookTable();
        VBox.setVgrow(bookTable, Priority.ALWAYS);
        panel.getChildren().add(bookTable);

        // 状态信息
        statusLabel = new Label();
        statusLabel.setFont(Font.font(13));
        panel.getChildren().add(statusLabel);

        return panel;
    }

    @SuppressWarnings("unchecked")
    private TableView<Book> createBookTable() {
        TableView<Book> table = new TableView<>();

        TableColumn<Book, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        isbnCol.setPrefWidth(120);

        TableColumn<Book, String> titleCol = new TableColumn<>("书名");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleCol.setPrefWidth(200);

        TableColumn<Book, String> authorCol = new TableColumn<>("作者");
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        authorCol.setPrefWidth(120);

        TableColumn<Book, String> catCol = new TableColumn<>("分类");
        catCol.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        catCol.setPrefWidth(100);

        TableColumn<Book, Integer> availCol = new TableColumn<>("可借数量");
        availCol.setCellValueFactory(new PropertyValueFactory<>("availableCopies"));
        availCol.setPrefWidth(80);

        TableColumn<Book, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(100);
        actionCol.setCellFactory(col -> new TableCell<Book, Void>() {
            private final JFXButton borrowBtn = new JFXButton("借阅");
            {
                borrowBtn.getStyleClass().addAll("jfx-button", "success");
                borrowBtn.setStyle("-fx-padding: 4 14 4 14; -fx-font-size: 12px;");
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); }
                else {
                    Book b = getTableRow().getItem();
                    borrowBtn.setOnAction(e -> borrowBook(b));
                    borrowBtn.setDisable(!b.isAvailable());
                    setGraphic(borrowBtn);
                }
            }
        });

        table.getColumns().addAll(isbnCol, titleCol, authorCol, catCol, availCol, actionCol);
        table.setItems(FXCollections.observableArrayList(bookService.getAllBooks().stream()
                .filter(Book::isAvailable).toList()));
        return table;
    }

    private VBox createCurrentBorrowPanel() {
        VBox panel = new VBox(10);
        panel.setPadding(new Insets(10));

        Label title = new Label("当前借阅记录");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));

        recordTable = createRecordTable();
        VBox.setVgrow(recordTable, Priority.ALWAYS);

        JFXButton refreshBtn = new JFXButton("刷新");
        refreshBtn.getStyleClass().addAll("jfx-button", "primary");
        refreshBtn.setOnAction(e -> refreshRecords());

        panel.getChildren().addAll(title, recordTable, refreshBtn);
        return panel;
    }

    @SuppressWarnings("unchecked")
    private TableView<BorrowRecord> createRecordTable() {
        TableView<BorrowRecord> table = new TableView<>();

        TableColumn<BorrowRecord, String> userCol = new TableColumn<>("读者");
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        TableColumn<BorrowRecord, String> bookCol = new TableColumn<>("图书");
        bookCol.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        TableColumn<BorrowRecord, String> borrowCol = new TableColumn<>("借阅日期");
        borrowCol.setCellValueFactory(cell -> {
            var d = cell.getValue().getBorrowDate();
            return new javafx.beans.property.SimpleStringProperty(
                    d != null ? d.toLocalDate().toString() : "");
        });
        TableColumn<BorrowRecord, String> dueCol = new TableColumn<>("应还日期");
        dueCol.setCellValueFactory(cell -> {
            var d = cell.getValue().getDueDate();
            return new javafx.beans.property.SimpleStringProperty(
                    d != null ? d.toLocalDate().toString() : "");
        });
        TableColumn<BorrowRecord, String> statusCol = new TableColumn<>("状态");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<BorrowRecord, String>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setText(null);
                else {
                    setText(switch (item) {
                        case "borrowed" -> "借阅中"; case "overdue" -> "已逾期"; default -> item;
                    });
                    setTextFill("overdue".equals(item) ? Color.RED : Color.GREEN);
                }
            }
        });

        TableColumn<BorrowRecord, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(140);
        actionCol.setCellFactory(col -> new TableCell<BorrowRecord, Void>() {
            private final JFXButton renewBtn = new JFXButton("续借");
            private final JFXButton returnBtn = new JFXButton("归还");
            private final HBox box = new HBox(6);
            {
                renewBtn.getStyleClass().addAll("jfx-button", "warning");
                renewBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                returnBtn.getStyleClass().addAll("jfx-button", "success");
                returnBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                box.setAlignment(Pos.CENTER);
                box.getChildren().addAll(renewBtn, returnBtn);
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); }
                else {
                    BorrowRecord r = getTableRow().getItem();
                    renewBtn.setDisable(!r.canRenew());
                    renewBtn.setOnAction(e -> {
                        String result = borrowService.renewBook(r.getId());
                        statusLabel.setText(result);
                        refreshRecords();
                    });
                    returnBtn.setOnAction(e -> {
                        String result = borrowService.returnBook(r.getId());
                        statusLabel.setText(result);
                        refreshRecords();
                    });
                    setGraphic(box);
                }
            }
        });

        table.getColumns().addAll(userCol, bookCol, borrowCol, dueCol, statusCol, actionCol);
        refreshRecordsData(table);
        return table;
    }

    private void searchBooks() {
        String keyword = searchBookField.getText().trim();
        if (keyword.isEmpty()) {
            bookTable.setItems(FXCollections.observableArrayList(bookService.getAllBooks().stream()
                    .filter(Book::isAvailable).toList()));
        } else {
            bookTable.setItems(FXCollections.observableArrayList(bookService.searchBooks(keyword, null, "all")));
        }
    }

    private void searchByIsbn() {
        String isbn = isbnField.getText().trim();
        if (!isbn.isEmpty()) {
            Book book = bookService.getBookByIsbn(isbn);
            if (book != null) {
                bookTable.setItems(FXCollections.observableArrayList(book));
                statusLabel.setText("");
            } else {
                statusLabel.setText("未找到ISBN: " + isbn);
            }
        }
    }

    private void borrowBook(Book book) {
        try {
            int uid = Integer.parseInt(userIdField.getText().trim());
            User user = userService.getUserById(uid);
            if (user == null) {
                statusLabel.setText("读者不存在");
                return;
            }
            String result = borrowService.borrowBook(user, book);
            statusLabel.setText(result);
            if ("SUCCESS".equals(result)) {
                searchBooks(); // 刷新列表
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("请输入有效的读者ID");
        }
    }

    private void refreshRecords() {
        refreshRecordsData(recordTable);
    }

    private void refreshRecordsData(TableView<BorrowRecord> table) {
        var records = borrowService.getCurrentBorrows();
        table.setItems(FXCollections.observableArrayList(records));
    }
}
