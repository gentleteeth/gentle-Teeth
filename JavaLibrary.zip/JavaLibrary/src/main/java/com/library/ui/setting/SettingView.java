package com.library.ui.setting;

import com.jfoenix.controls.*;
import com.library.service.*;
import com.library.util.ThemeManager;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;

import java.io.File;

/**
 * 系统设置视图 —— 主题切换、数据备份与恢复
 */
public class SettingView extends BorderPane {
    private final BookService bookService;
    private final BackupService backupService;
    private Label themeStatusLabel;

    public SettingView(BookService bookService, BackupService backupService) {
        this.bookService = bookService;
        this.backupService = backupService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(16));

        VBox mainPanel = new VBox(25);
        mainPanel.setPadding(new Insets(10));

        Label title = new Label("系统设置");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 20));
        title.setTextFill(Color.valueOf("#2c3e50"));

        // 主题切换
        VBox themeSection = new VBox(12);
        themeSection.getStyleClass().add("card");
        Label themeTitle = new Label("主题设置");
        themeTitle.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));

        HBox themeRow = new HBox(15);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        themeStatusLabel = new Label("当前主题：" + ThemeManager.getInstance().getCurrentThemeName());
        themeStatusLabel.setFont(Font.font(14));

        JFXButton toggleBtn = new JFXButton("切换主题");
        toggleBtn.getStyleClass().addAll("jfx-button", "primary");
        FontAwesomeIconView paintIcon = new FontAwesomeIconView(FontAwesomeIcon.PAINT_BRUSH);
        paintIcon.setSize("14");
        toggleBtn.setGraphic(paintIcon);
        toggleBtn.setOnAction(e -> toggleTheme());

        themeRow.getChildren().addAll(themeStatusLabel, toggleBtn);
        themeSection.getChildren().addAll(themeTitle, themeRow);

        // 数据备份
        VBox backupSection = new VBox(12);
        backupSection.getStyleClass().add("card");
        Label backupTitle = new Label("数据备份与恢复");
        backupTitle.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));

        HBox backupRow = new HBox(15);
        backupRow.setAlignment(Pos.CENTER_LEFT);

        JFXButton backupBtn = new JFXButton("导出数据库SQL备份");
        backupBtn.getStyleClass().addAll("jfx-button", "success");
        FontAwesomeIconView saveIcon = new FontAwesomeIconView(FontAwesomeIcon.DATABASE);
        saveIcon.setSize("14");
        backupBtn.setGraphic(saveIcon);
        backupBtn.setOnAction(e -> handleBackup());

        JFXButton restoreBtn = new JFXButton("从SQL文件恢复");
        restoreBtn.getStyleClass().addAll("jfx-button", "warning");
        FontAwesomeIconView restoreIcon = new FontAwesomeIconView(FontAwesomeIcon.UPLOAD);
        restoreIcon.setSize("14");
        restoreBtn.setGraphic(restoreIcon);
        restoreBtn.setOnAction(e -> handleRestore());

        backupRow.getChildren().addAll(backupBtn, restoreBtn);

        Label warningLabel = new Label("注意：恢复操作将覆盖当前数据库，系统会自动在恢复前创建备份");
        warningLabel.setFont(Font.font(12));
        warningLabel.setTextFill(Color.valueOf("#7f8c8d"));

        backupSection.getChildren().addAll(backupTitle, backupRow, warningLabel);

        // 关于信息
        VBox aboutSection = new VBox(12);
        aboutSection.getStyleClass().add("card");
        Label aboutTitle = new Label("关于系统");
        aboutTitle.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));

        GridPane infoGrid = new GridPane();
        infoGrid.setHgap(12);
        infoGrid.setVgap(8);
        addInfoRow(infoGrid, 0, "系统名称", "图书管理系统 (Library Management System)");
        addInfoRow(infoGrid, 1, "版本", "v1.0.0");
        addInfoRow(infoGrid, 2, "技术栈", "Java 17 + JavaFX 17 + SQLite + JFoenix + Apache POI + Log4j2");
        addInfoRow(infoGrid, 3, "数据库", "SQLite (嵌入式)");
        addInfoRow(infoGrid, 4, "设计模式", "工厂模式、策略模式、观察者模式、装饰器模式、单例模式");

        aboutSection.getChildren().addAll(aboutTitle, infoGrid);

        mainPanel.getChildren().addAll(title, themeSection, backupSection, aboutSection);
        ScrollPane scrollPane = new ScrollPane(mainPanel);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");
        setCenter(scrollPane);
    }

    private void toggleTheme() {
        ThemeManager.getInstance().toggle();
        themeStatusLabel.setText("当前主题：" + ThemeManager.getInstance().getCurrentThemeName());

        // 更新场景样式
        Scene scene = getScene();
        if (scene != null) {
            String theme = ThemeManager.getInstance().getCurrentThemePath();
            scene.getStylesheets().clear();
            scene.getStylesheets().add(getClass().getResource(theme).toExternalForm());
        }

        showInfo("主题已切换", "已切换为" + ThemeManager.getInstance().getCurrentThemeName());
    }

    private void handleBackup() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("选择备份保存位置");
        chooser.setInitialFileName("library_backup_" +
                java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".sql");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL文件", "*.sql"));
        File file = chooser.showSaveDialog(getScene().getWindow());
        if (file != null) {
            boolean ok = backupService.backupToSql(file);
            if (ok) {
                showInfo("备份成功", "数据库已备份到: " + file.getAbsolutePath());
            } else {
                showError("备份失败");
            }
        }
    }

    private void handleRestore() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "确定要从SQL文件恢复数据库吗？\n当前数据将被覆盖，系统会自动创建备份。");
        confirm.setTitle("恢复确认");
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                FileChooser chooser = new FileChooser();
                chooser.setTitle("选择SQL备份文件");
                chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL文件", "*.sql"));
                File file = chooser.showOpenDialog(getScene().getWindow());
                if (file != null) {
                    boolean ok = backupService.restoreFromSql(file);
                    if (ok) {
                        showInfo("恢复成功", "数据库已从 " + file.getName() + " 恢复，请重新登录");
                    } else {
                        showError("恢复失败，已从自动备份恢复");
                    }
                }
            }
        });
    }

    private void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lbl = new Label(label + "：");
        lbl.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 13));
        grid.add(lbl, 0, row);
        Label val = new Label(value);
        val.setFont(Font.font(13));
        val.setWrapText(true);
        grid.add(val, 1, row);
    }

    private void showInfo(String title, String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }

    private void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }
}
