package com.library.ui.user;

import com.jfoenix.controls.*;
import com.library.model.User;
import com.library.service.UserService;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.Optional;

/**
 * 用户添加/编辑对话框
 */
public class UserDialog {
    private final UserService userService;
    private final User existingUser;
    private Dialog<User> dialog;

    private JFXTextField usernameField, emailField, phoneField;
    private JFXPasswordField passwordField;
    private JFXComboBox<String> roleCombo;

    public UserDialog(UserService userService, User existingUser) {
        this.userService = userService;
        this.existingUser = existingUser;
    }

    public Optional<User> showAndWait() {
        dialog = new Dialog<>();
        dialog.setTitle(existingUser == null ? "添加用户" : "编辑用户");
        dialog.setHeaderText(null);

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        int row = 0;
        usernameField = addField(grid, "用户名：", row++);
        passwordField = new JFXPasswordField();
        passwordField.setPromptText(existingUser == null ? "请输入密码" : "留空则不修改");
        passwordField.setLabelFloat(true);
        passwordField.setPrefWidth(250);
        grid.add(new Label("密码："), 0, row);
        grid.add(passwordField, 1, row++);

        emailField = addField(grid, "邮箱：", row++);
        phoneField = addField(grid, "手机号：", row++);

        grid.add(new Label("角色："), 0, row);
        roleCombo = new JFXComboBox<>();
        roleCombo.getItems().addAll("admin", "librarian", "member");
        var converter = new javafx.util.StringConverter<String>() {
            @Override public String toString(String s) {
                return switch (s) {
                    case "admin" -> "管理员"; case "librarian" -> "图书管理员"; case "member" -> "读者"; default -> s;
                };
            }
            @Override public String fromString(String s) { return s; }
        };
        roleCombo.setConverter(converter);
        roleCombo.getSelectionModel().select(existingUser != null ? existingUser.getRole() : "member");
        grid.add(roleCombo, 1, row++);

        // 填充已有数据
        if (existingUser != null) {
            usernameField.setText(existingUser.getUsername());
            emailField.setText(existingUser.getEmail() != null ? existingUser.getEmail() : "");
            phoneField.setText(existingUser.getPhone() != null ? existingUser.getPhone() : "");
        }

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStyleClass().add("dialog-container");

        ButtonType saveBtnType = new ButtonType("保存", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtnType, ButtonType.CANCEL);

        Button saveBtn = (Button) dialog.getDialogPane().lookupButton(saveBtnType);
        saveBtn.addEventFilter(javafx.event.ActionEvent.ACTION, e -> {
            if (!validate()) e.consume();
        });

        dialog.setResultConverter(btn -> {
            if (btn == saveBtnType) {
                String uname = usernameField.getText().trim();
                String pwd = passwordField.getText();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String role = roleCombo.getValue();

                if (existingUser == null) {
                    // 新增
                    boolean ok = userService.addUser(uname, pwd, role, email, phone);
                    if (ok) return userService.getAllUsers().stream()
                            .filter(u -> u.getUsername().equals(uname)).findFirst().orElse(null);
                } else {
                    // 更新
                    existingUser.setUsername(uname);
                    existingUser.setEmail(email);
                    existingUser.setPhone(phone);
                    existingUser.setRole(role);
                    if (!pwd.isEmpty()) {
                        userService.changePassword(existingUser.getId(), pwd);
                    }
                    userService.updateUser(existingUser);
                    return existingUser;
                }
            }
            return null;
        });

        return dialog.showAndWait();
    }

    private JFXTextField addField(GridPane grid, String label, int row) {
        grid.add(new Label(label), 0, row);
        JFXTextField field = new JFXTextField();
        field.setPrefWidth(250);
        grid.add(field, 1, row);
        return field;
    }

    private boolean validate() {
        String uname = usernameField.getText().trim();
        if (uname.isEmpty()) {
            showAlert("用户名不能为空"); return false;
        }
        if (existingUser == null) {
            String pwd = passwordField.getText();
            if (pwd.isEmpty()) {
                showAlert("密码不能为空"); return false;
            }
            if (pwd.length() < 3) {
                showAlert("密码长度至少3位"); return false;
            }
            // 检查用户名是否已存在
            User exist = userService.getAllUsers().stream()
                    .filter(u -> u.getUsername().equals(uname)).findFirst().orElse(null);
            if (exist != null) {
                showAlert("用户名已存在"); return false;
            }
        }
        return true;
    }

    private void showAlert(String msg) {
        new Alert(Alert.AlertType.WARNING, msg).showAndWait();
    }
}
