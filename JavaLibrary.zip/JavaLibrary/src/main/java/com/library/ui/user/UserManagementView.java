package com.library.ui.user;

import com.jfoenix.controls.*;
import com.library.model.*;
import com.library.service.UserService;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.util.List;
import java.util.Optional;

/**
 * 读者管理视图
 */
public class UserManagementView extends BorderPane {
    private final UserService userService;
    private TableView<User> tableView;
    private JFXTextField searchField;
    private JFXComboBox<String> roleFilter;

    public UserManagementView(UserService userService) {
        this.userService = userService;
        setupUI();
    }

    private void setupUI() {
        setPadding(new Insets(10));

        VBox mainPanel = new VBox(12);

        Label title = new Label("读者管理");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 20));
        title.setTextFill(Color.valueOf("#2c3e50"));

        // 搜索栏
        HBox searchBar = new HBox(12);
        searchBar.setAlignment(Pos.CENTER_LEFT);
        searchBar.getStyleClass().add("search-bar");

        searchField = new JFXTextField();
        searchField.setPromptText("搜索用户名/邮箱/手机...");
        searchField.setPrefWidth(250);

        roleFilter = new JFXComboBox<>();
        roleFilter.getItems().addAll("全部", "admin", "librarian", "member");
        roleFilter.getSelectionModel().select(0);
        roleFilter.setConverter(new javafx.util.StringConverter<String>() {
            @Override public String toString(String s) {
                return switch (s) {
                    case "admin" -> "管理员"; case "librarian" -> "图书管理员";
                    case "member" -> "读者"; default -> "全部";
                };
            }
            @Override public String fromString(String s) { return s; }
        });

        JFXButton searchBtn = new JFXButton("搜索");
        searchBtn.getStyleClass().addAll("jfx-button", "primary");
        searchBtn.setOnAction(e -> doSearch());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        JFXButton addBtn = new JFXButton("添加用户");
        addBtn.getStyleClass().addAll("jfx-button", "success");
        FontAwesomeIconView plusIcon = new FontAwesomeIconView(FontAwesomeIcon.PLUS);
        plusIcon.setSize("14");
        addBtn.setGraphic(plusIcon);
        addBtn.setOnAction(e -> showAddDialog());

        searchBar.getChildren().addAll(searchField, roleFilter, searchBtn, spacer, addBtn);

        // 表格
        tableView = createTable();
        VBox.setVgrow(tableView, Priority.ALWAYS);

        mainPanel.getChildren().addAll(title, searchBar, tableView);
        setCenter(mainPanel);
    }

    @SuppressWarnings("unchecked")
    private TableView<User> createTable() {
        TableView<User> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);

        TableColumn<User, String> usernameCol = new TableColumn<>("用户名");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        usernameCol.setPrefWidth(120);

        TableColumn<User, String> roleCol = new TableColumn<>("角色");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));
        roleCol.setCellFactory(col -> new TableCell<User, String>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setText(null);
                else setText(switch (item) {
                    case "admin" -> "管理员"; case "librarian" -> "图书管理员";
                    case "member" -> "读者"; default -> item;
                });
            }
        });

        TableColumn<User, String> emailCol = new TableColumn<>("邮箱");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        emailCol.setPrefWidth(180);

        TableColumn<User, String> phoneCol = new TableColumn<>("手机");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        phoneCol.setPrefWidth(130);

        TableColumn<User, Void> actionCol = new TableColumn<>("操作");
        actionCol.setPrefWidth(150);
        actionCol.setCellFactory(col -> new TableCell<User, Void>() {
            private final JFXButton editBtn = new JFXButton("编辑");
            private final JFXButton deleteBtn = new JFXButton("删除");
            private final HBox box = new HBox(8);
            {
                editBtn.getStyleClass().addAll("jfx-button", "warning");
                editBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                deleteBtn.getStyleClass().addAll("jfx-button", "danger");
                deleteBtn.setStyle("-fx-padding: 4 10 4 10; -fx-font-size: 11px;");
                box.setAlignment(Pos.CENTER);
                box.getChildren().addAll(editBtn, deleteBtn);
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); }
                else {
                    User u = getTableRow().getItem();
                    editBtn.setOnAction(e -> showEditDialog(u));
                    deleteBtn.setOnAction(e -> {
                        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                                "确定删除用户 " + u.getUsername() + " 吗？");
                        confirm.setTitle("删除确认");
                        confirm.showAndWait().ifPresent(r -> {
                            if (r == ButtonType.OK) {
                                userService.deleteUser(u.getId());
                                refreshTable();
                            }
                        });
                    });
                    setGraphic(box);
                }
            }
        });

        table.getColumns().addAll(idCol, usernameCol, roleCol, emailCol, phoneCol, actionCol);
        refreshTableData(table);
        return table;
    }

    private void doSearch() {
        String keyword = searchField.getText().trim();
        String role = roleFilter.getValue();
        List<User> users;
        if (!keyword.isEmpty()) {
            users = userService.searchUsers(keyword);
        } else if (!"全部".equals(role) && role != null) {
            users = userService.getUsersByRole(role);
        } else {
            users = userService.getAllUsers();
        }
        tableView.setItems(FXCollections.observableArrayList(users));
    }

    private void showAddDialog() {
        UserDialog dialog = new UserDialog(userService, null);
        dialog.showAndWait().ifPresent(u -> refreshTable());
    }

    private void showEditDialog(User user) {
        UserDialog dialog = new UserDialog(userService, user);
        dialog.showAndWait().ifPresent(u -> refreshTable());
    }

    private void refreshTable() {
        refreshTableData(tableView);
    }

    private void refreshTableData(TableView<User> table) {
        table.setItems(FXCollections.observableArrayList(userService.getAllUsers()));
    }
}
