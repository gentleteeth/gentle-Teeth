package com.library.ui.login;

import com.jfoenix.controls.*;
import com.library.service.UserService;
import com.library.ui.main.MainView;
import com.library.util.ThemeManager;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * 登录界面 —— 全屏居中卡片式设计
 */
public class LoginView {
    private final Stage stage;
    private final UserService userService;
    private JFXTextField usernameField;
    private JFXPasswordField passwordField;
    private Label errorLabel;
    private StackPane root;

    public LoginView(Stage stage, UserService userService) {
        this.stage = stage;
        this.userService = userService;
    }

    public void show() {
        root = new StackPane();
        root.getStyleClass().add("login-background");

        // 主卡片
        VBox card = new VBox(20);
        card.getStyleClass().add("login-card");
        card.setAlignment(Pos.CENTER);

        // Logo图标
        FontAwesomeIconView logoIcon = new FontAwesomeIconView(FontAwesomeIcon.BOOK);
        logoIcon.setSize("48");
        logoIcon.setFill(Color.valueOf("#3498db"));

        // 标题
        Label titleLabel = new Label("图书管理系统");
        titleLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 26));
        titleLabel.setTextFill(Color.valueOf("#2c3e50"));

        Label subtitleLabel = new Label("Library Management System");
        subtitleLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 13));
        subtitleLabel.setTextFill(Color.valueOf("#7f8c8d"));

        VBox headerBox = new VBox(5, logoIcon, titleLabel, subtitleLabel);
        headerBox.setAlignment(Pos.CENTER);

        // 输入区域
        VBox inputBox = new VBox(15);
        inputBox.setAlignment(Pos.CENTER);
        inputBox.setPadding(new Insets(10, 0, 0, 0));

        FontAwesomeIconView userIcon = new FontAwesomeIconView(FontAwesomeIcon.USER);
        userIcon.setSize("16");
        userIcon.setFill(Color.valueOf("#7f8c8d"));

        usernameField = new JFXTextField();
        usernameField.setPromptText("用户名");
        usernameField.setLabelFloat(true);
        usernameField.setPrefWidth(300);
        usernameField.setMaxWidth(300);

        FontAwesomeIconView lockIcon = new FontAwesomeIconView(FontAwesomeIcon.LOCK);
        lockIcon.setSize("16");
        lockIcon.setFill(Color.valueOf("#7f8c8d"));

        passwordField = new JFXPasswordField();
        passwordField.setPromptText("密码");
        passwordField.setLabelFloat(true);
        passwordField.setPrefWidth(300);
        passwordField.setMaxWidth(300);

        errorLabel = new Label();
        errorLabel.setTextFill(Color.valueOf("#e74c3c"));
        errorLabel.setFont(Font.font(12));
        errorLabel.setVisible(false);
        errorLabel.setManaged(false);

        inputBox.getChildren().addAll(usernameField, passwordField, errorLabel);

        // 按钮区域
        JFXButton loginBtn = new JFXButton("登  录");
        loginBtn.getStyleClass().addAll("jfx-button", "primary");
        loginBtn.setPrefWidth(300);
        loginBtn.setMaxWidth(300);
        FontAwesomeIconView signInIcon = new FontAwesomeIconView(FontAwesomeIcon.SIGN_IN);
        signInIcon.setSize("16");
        loginBtn.setGraphic(signInIcon);
        loginBtn.setOnAction(e -> handleLogin());

        JFXButton registerBtn = new JFXButton("注册新账号");
        registerBtn.getStyleClass().add("jfx-button");
        registerBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #3498db;");
        registerBtn.setOnAction(e -> showRegisterDialog());

        // 底部提示
        Label hintLabel = new Label("提示：测试账号 admin / admin123  或  reader / reader123");
        hintLabel.setFont(Font.font(11));
        hintLabel.setTextFill(Color.valueOf("#95a5a6"));

        VBox buttonBox = new VBox(12, loginBtn, registerBtn, hintLabel);
        buttonBox.setAlignment(Pos.CENTER);

        card.getChildren().addAll(headerBox, new Separator(), inputBox, buttonBox);

        // 阴影效果
        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.rgb(0, 0, 0, 0.25));
        shadow.setRadius(20);
        shadow.setOffsetY(8);
        card.setEffect(shadow);

        root.getChildren().add(card);

        // 回车键登录
        Scene scene = new Scene(root, 900, 600);
        applyTheme(scene);
        scene.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case ENTER -> handleLogin();
                default -> {}
            }
        });

        stage.setTitle("图书管理系统 - 登录");
        stage.setScene(scene);
        stage.setMinWidth(800);
        stage.setMinHeight(550);
        stage.centerOnScreen();
        stage.show();
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("请输入用户名和密码");
            return;
        }

        var user = userService.login(username, password);
        if (user != null) {
            // 登录成功，跳转主界面
            new MainView(stage, userService).show();
        } else {
            showError("用户名或密码错误");
        }
    }

    private void showRegisterDialog() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        JFXTextField regUserField = new JFXTextField();
        regUserField.setPromptText("用户名");
        regUserField.setLabelFloat(true);

        JFXPasswordField regPwdField = new JFXPasswordField();
        regPwdField.setPromptText("密码");
        regPwdField.setLabelFloat(true);

        JFXPasswordField regPwd2Field = new JFXPasswordField();
        regPwd2Field.setPromptText("确认密码");
        regPwd2Field.setLabelFloat(true);

        JFXTextField emailField = new JFXTextField();
        emailField.setPromptText("邮箱");
        emailField.setLabelFloat(true);

        JFXTextField phoneField = new JFXTextField();
        phoneField.setPromptText("手机号");
        phoneField.setLabelFloat(true);

        Label msgLabel = new Label();
        msgLabel.setTextFill(Color.valueOf("#e74c3c"));

        content.getChildren().addAll(regUserField, regPwdField, regPwd2Field, emailField, phoneField, msgLabel);

        Alert dialog = new Alert(Alert.AlertType.CONFIRMATION);
        dialog.setTitle("用户注册");
        dialog.setHeaderText("注册新用户账号");
        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().setMinWidth(400);

        Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.setText("注册");
        okButton.addEventFilter(javafx.event.ActionEvent.ACTION, e -> {
            String uname = regUserField.getText().trim();
            String pwd = regPwdField.getText();
            String pwd2 = regPwd2Field.getText();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();

            if (uname.isEmpty() || pwd.isEmpty()) {
                msgLabel.setText("用户名和密码不能为空");
                e.consume();
                return;
            }
            if (!pwd.equals(pwd2)) {
                msgLabel.setText("两次密码不一致");
                e.consume();
                return;
            }
            if (pwd.length() < 3) {
                msgLabel.setText("密码长度至少3位");
                e.consume();
                return;
            }
            boolean success = userService.register(uname, pwd, email, phone);
            if (!success) {
                msgLabel.setText("用户名已存在");
                e.consume();
            }
        });

        dialog.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                // 注册成功提示
                Alert info = new Alert(Alert.AlertType.INFORMATION, "注册成功，请登录");
                info.showAndWait();
            }
        });
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
    }

    public void applyTheme(Scene scene) {
        String theme = ThemeManager.getInstance().getCurrentThemePath();
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource(theme).toExternalForm());
    }
}
