package com.library.model;

/**
 * 普通读者 —— 可借阅、预约、评论图书
 */
public class Member extends User {

    public static final int MAX_BORROW_LIMIT = 5;

    public Member() {}

    public Member(int id, String username, String password, String email, String phone) {
        super(id, username, password, "member", email, phone);
    }

    @Override
    public String getRole() { return role != null ? role : "member"; }

    public int getMaxBorrowLimit() { return MAX_BORROW_LIMIT; }
    public boolean canBorrow() { return true; }
    public boolean canReserve() { return true; }
    public boolean canReview() { return true; }
}
