package com.library.model;

/**
 * 图书管理员 —— 管理图书和借阅事务
 */
public class Librarian extends User {

    public Librarian() {}

    public Librarian(int id, String username, String password, String email, String phone) {
        super(id, username, password, "librarian", email, phone);
    }

    @Override
    public String getRole() { return role != null ? role : "librarian"; }

    public boolean canManageBooks() { return true; }
    public boolean canManageBorrows() { return true; }
    public boolean canViewReports() { return true; }
    public boolean canExportData() { return true; }
    public boolean canManageUsers() { return false; }
    public boolean canManageSystem() { return false; }
}
