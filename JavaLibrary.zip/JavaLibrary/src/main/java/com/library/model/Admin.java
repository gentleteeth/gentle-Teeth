package com.library.model;

/**
 * 系统管理员 —— 拥有最高权限
 */
public class Admin extends User {

    public Admin() {}

    public Admin(int id, String username, String password, String email, String phone) {
        super(id, username, password, "admin", email, phone);
    }

    @Override
    public String getRole() { return role != null ? role : "admin"; }

    public boolean canManageUsers() { return true; }
    public boolean canManageSystem() { return true; }
    public boolean canManageBooks() { return true; }
    public boolean canManageBorrows() { return true; }
    public boolean canViewReports() { return true; }
    public boolean canExportData() { return true; }
    public boolean canBackupRestore() { return true; }
}
