package com.library.model;

/**
 * 图书实体类
 */
public class Book {
    private int id;
    private String isbn;
    private String title;
    private String author;
    private String publisher;
    private int categoryId;
    private String categoryName;   // 联表查询时填充
    private int publishYear;
    private int totalCopies;
    private int availableCopies;
    private String location;
    private String description;
    private String coverImage;

    public Book() {}

    public Book(int id, String isbn, String title, String author, String publisher,
                int categoryId, int publishYear, int totalCopies, int availableCopies,
                String location, String description) {
        this.id = id;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.categoryId = categoryId;
        this.publishYear = publishYear;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
        this.location = location;
        this.description = description;
    }

    /** 当前是否可借 */
    public boolean isAvailable() {
        return availableCopies > 0;
    }

    /** 借出一本 */
    public void borrowOne() {
        if (availableCopies > 0) availableCopies--;
    }

    /** 归还一本 */
    public void returnOne() {
        if (availableCopies < totalCopies) availableCopies++;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    public int getPublishYear() { return publishYear; }
    public void setPublishYear(int publishYear) { this.publishYear = publishYear; }
    public int getTotalCopies() { return totalCopies; }
    public void setTotalCopies(int totalCopies) { this.totalCopies = totalCopies; }
    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) { this.availableCopies = availableCopies; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCoverImage() { return coverImage; }
    public void setCoverImage(String coverImage) { this.coverImage = coverImage; }

    @Override
    public String toString() {
        return title + " - " + author;
    }
}
