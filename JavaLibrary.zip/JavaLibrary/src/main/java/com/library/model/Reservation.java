package com.library.model;

import java.time.LocalDateTime;

/**
 * 图书预约实体
 */
public class Reservation {
    private int id;
    private int userId;
    private String username;      // 联表查询
    private int bookId;
    private String bookTitle;     // 联表查询
    private LocalDateTime reserveDate;
    private String status;        // pending / fulfilled / cancelled

    public Reservation() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String bookTitle) { this.bookTitle = bookTitle; }
    public LocalDateTime getReserveDate() { return reserveDate; }
    public void setReserveDate(LocalDateTime reserveDate) { this.reserveDate = reserveDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
