package com.library.model;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 借阅记录实体
 */
public class BorrowRecord {
    private int id;
    private int userId;
    private String username;      // 联表查询
    private int bookId;
    private String bookTitle;     // 联表查询
    private String bookIsbn;      // 联表查询
    private LocalDateTime borrowDate;
    private LocalDateTime dueDate;
    private LocalDateTime returnDate;
    private String status;        // borrowed / returned / overdue
    private double fineAmount;
    private int renewed;          // 0=未续借, 1=已续借

    public static final double FINE_PER_DAY = 0.1;

    public BorrowRecord() {}

    /** 计算逾期天数 */
    public long getOverdueDays() {
        if (dueDate == null) return 0;
        if (returnDate != null) {
            if (returnDate.isAfter(dueDate)) {
                return ChronoUnit.DAYS.between(dueDate, returnDate);
            }
        } else if (LocalDateTime.now().isAfter(dueDate)) {
            return ChronoUnit.DAYS.between(dueDate, LocalDateTime.now());
        }
        return 0;
    }

    /** 计算罚款金额 */
    public double calculateFine() {
        long days = getOverdueDays();
        return days > 0 ? days * FINE_PER_DAY : 0;
    }

    /** 是否已逾期 */
    public boolean isOverdue() {
        return dueDate != null && returnDate == null && LocalDateTime.now().isAfter(dueDate);
    }

    /** 是否可以续借（未归还、未逾期、未续借过） */
    public boolean canRenew() {
        return "borrowed".equals(status) && renewed == 0 && !isOverdue();
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String bookTitle) { this.bookTitle = bookTitle; }
    public String getBookIsbn() { return bookIsbn; }
    public void setBookIsbn(String bookIsbn) { this.bookIsbn = bookIsbn; }
    public LocalDateTime getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDateTime borrowDate) { this.borrowDate = borrowDate; }
    public LocalDateTime getDueDate() { return dueDate; }
    public void setDueDate(LocalDateTime dueDate) { this.dueDate = dueDate; }
    public LocalDateTime getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDateTime returnDate) { this.returnDate = returnDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public double getFineAmount() { return fineAmount; }
    public void setFineAmount(double fineAmount) { this.fineAmount = fineAmount; }
    public int getRenewed() { return renewed; }
    public void setRenewed(int renewed) { this.renewed = renewed; }
}
