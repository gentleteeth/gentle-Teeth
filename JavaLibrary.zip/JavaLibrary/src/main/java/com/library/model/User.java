package com.library.model;

import java.time.LocalDateTime;

/**
 * 用户抽象基类 —— 定义所有用户的共同属性和行为
 */
public abstract class User {
    protected int id;
    protected String username;
    protected String password;
    protected String role;
    protected String email;
    protected String phone;
    protected LocalDateTime createdAt;

    public User() {}

    public User(int id, String username, String password, String role, String email, String phone) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.phone = phone;
    }

    /** 获取用户角色，由子类实现，返回与子类对应的固定角色值 */
    public abstract String getRole();

    /** 获取角色对应的中文显示名称 */
    public String getRoleDisplayName() {
        return switch (getRole()) {
            case "admin" -> "系统管理员";
            case "librarian" -> "图书管理员";
            case "member" -> "普通读者";
            default -> "未知角色";
        };
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    // setRole 仅更新内部字段，getRole() 由子类硬编码返回，
    // 若需动态角色，请移除子类的 getRole() override，改用本字段
    public void setRole(String role) { this.role = role; }
    /** 获取存储在字段中的角色值（与子类 override 的 getRole 不同，此处返回字段实际值） */
    public String getStoredRole() { return role; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
