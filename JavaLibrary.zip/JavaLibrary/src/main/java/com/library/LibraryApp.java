package com.library;

import com.library.dao.DatabaseManager;
import com.library.service.UserService;
import com.library.ui.login.LoginView;
import javafx.application.Application;
import javafx.stage.Stage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 图书管理系统 —— 主启动类
 *
 * 技术栈：Java 17 + JavaFX 17 + SQLite + JFoenix + FontAwesomeFX + Apache POI + Log4j2
 * 设计模式：工厂模式、策略模式、观察者模式、装饰器模式、单例模式
 * 架构：MVC分层 (model / dao / service / ui)
 */
public class LibraryApp extends Application {
    private static final Logger logger = LogManager.getLogger(LibraryApp.class);

    public static void main(String[] args) {
        logger.info("========================================");
        logger.info("  图书管理系统 (Library Management System)");
        logger.info("  v1.0.0 - Java 17 + JavaFX 17");
        logger.info("========================================");
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // 初始化数据库（单例模式，首次调用自动建表并插入测试数据）
        logger.info("正在初始化数据库...");
        DatabaseManager.getInstance();
        logger.info("数据库初始化完成");

        // 创建用户服务
        UserService userService = new UserService();

        // 显示登录界面
        LoginView loginView = new LoginView(primaryStage, userService);
        loginView.show();

        logger.info("应用程序启动完成");

        // 应用关闭时的清理
        primaryStage.setOnCloseRequest(e -> {
            logger.info("应用程序关闭");
        });
    }

    @Override
    public void stop() {
        logger.info("图书管理系统已停止");
    }
}
