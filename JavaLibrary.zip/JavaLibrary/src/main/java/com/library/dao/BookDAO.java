package com.library.dao;

import com.library.model.Book;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 图书数据访问对象
 */
public class BookDAO {
    private static final Logger logger = LogManager.getLogger(BookDAO.class);

    /** 查询所有图书（含分类名称） */
    public List<Book> findAll() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT b.*, c.name as category_name FROM books b " +
                     "LEFT JOIN categories c ON b.category_id = c.id ORDER BY b.id";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapBook(rs));
        } catch (SQLException e) {
            logger.error("查询所有图书失败", e);
        }
        return list;
    }

    /** 根据ID查询 */
    public Book findById(int id) {
        String sql = "SELECT b.*, c.name as category_name FROM books b " +
                     "LEFT JOIN categories c ON b.category_id = c.id WHERE b.id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapBook(rs);
            }
        } catch (SQLException e) {
            logger.error("查询图书失败: id={}", id, e);
        }
        return null;
    }

    /** 根据ISBN查询 */
    public Book findByIsbn(String isbn) {
        String sql = "SELECT b.*, c.name as category_name FROM books b " +
                     "LEFT JOIN categories c ON b.category_id = c.id WHERE b.isbn = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, isbn);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapBook(rs);
            }
        } catch (SQLException e) {
            logger.error("按ISBN查询图书失败: {}", isbn, e);
        }
        return null;
    }

    /** 按分类查询 */
    public List<Book> findByCategory(int categoryId) {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT b.*, c.name as category_name FROM books b " +
                     "LEFT JOIN categories c ON b.category_id = c.id WHERE b.category_id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapBook(rs));
            }
        } catch (SQLException e) {
            logger.error("按分类查询图书失败", e);
        }
        return list;
    }

    /** 插入图书 */
    public boolean insert(Book book) {
        String sql = "INSERT INTO books (isbn, title, author, publisher, category_id, publish_year, " +
                     "total_copies, available_copies, location, description) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            setBookParams(ps, book);
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) book.setId(keys.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            logger.error("插入图书失败", e);
        }
        return false;
    }

    /** 更新图书 */
    public boolean update(Book book) {
        String sql = "UPDATE books SET isbn=?, title=?, author=?, publisher=?, category_id=?, " +
                     "publish_year=?, total_copies=?, available_copies=?, location=?, description=?, cover_image=? WHERE id=?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            setBookParams(ps, book);
            ps.setString(11, book.getCoverImage());
            ps.setInt(12, book.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("更新图书失败", e);
        }
        return false;
    }

    /** 删除图书 */
    public boolean delete(int id) {
        String sql = "DELETE FROM books WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("删除图书失败", e);
        }
        return false;
    }

    /** 更新可借数量 */
    public boolean updateAvailableCopies(int bookId, int availableCopies) {
        String sql = "UPDATE books SET available_copies = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, availableCopies);
            ps.setInt(2, bookId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("更新库存失败", e);
        }
        return false;
    }

    /** 原子化借出：available_copies > 0 时才扣减，避免竞态条件 */
    public boolean atomicDecrementAvailable(int bookId) {
        String sql = "UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("原子扣减库存失败", e);
        }
        return false;
    }

    /** 原子化归还：available_copies < total_copies 时才增加 */
    public boolean atomicIncrementAvailable(int bookId) {
        String sql = "UPDATE books SET available_copies = available_copies + 1 WHERE id = ? AND available_copies < total_copies";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("原子增加库存失败", e);
        }
        return false;
    }

    /** 检查图书是否有未归还的借阅记录（用于删除前校验） */
    public boolean hasActiveBorrows(int bookId) {
        String sql = "SELECT COUNT(*) FROM borrow_records WHERE book_id = ? AND status IN ('borrowed', 'overdue')";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            logger.error("检查活跃借阅记录失败", e);
        }
        return false;
    }

    /** 获取图书总数 */
    public int getTotalCount() {
        String sql = "SELECT COUNT(*) FROM books";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            logger.error("查询图书总数失败", e);
        }
        return 0;
    }

    /** 多条件搜索图书 */
    public List<Book> search(String keyword, Integer categoryId, String searchType) {
        List<Book> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT b.*, c.name as category_name FROM books b " +
            "LEFT JOIN categories c ON b.category_id = c.id WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            switch (searchType != null ? searchType : "title") {
                case "title" -> { sql.append("AND b.title LIKE ? "); params.add("%" + keyword + "%"); }
                case "author" -> { sql.append("AND b.author LIKE ? "); params.add("%" + keyword + "%"); }
                case "isbn" -> { sql.append("AND b.isbn LIKE ? "); params.add("%" + keyword + "%"); }
                case "all" -> {
                    sql.append("AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?) ");
                    String kw = "%" + keyword + "%";
                    params.add(kw); params.add(kw); params.add(kw);
                }
                default -> { sql.append("AND b.title LIKE ? "); params.add("%" + keyword + "%"); }
            }
        }
        if (categoryId != null && categoryId > 0) {
            sql.append("AND b.category_id = ? ");
            params.add(categoryId);
        }
        sql.append("ORDER BY b.id");

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapBook(rs));
            }
        } catch (SQLException e) {
            logger.error("搜索图书失败", e);
        }
        return list;
    }

    /** 按借阅次数排序获取热门图书 */
    public List<Book> findHotBooks(int limit) {
        List<Book> list = new ArrayList<>();
        String sql = """
            SELECT b.*, c.name as category_name, COUNT(br.id) as borrow_count
            FROM books b
            LEFT JOIN categories c ON b.category_id = c.id
            LEFT JOIN borrow_records br ON b.id = br.book_id
            GROUP BY b.id
            ORDER BY borrow_count DESC
            LIMIT ?
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapBook(rs));
            }
        } catch (SQLException e) {
            logger.error("查询热门图书失败", e);
        }
        return list;
    }

    private void setBookParams(PreparedStatement ps, Book book) throws SQLException {
        ps.setString(1, book.getIsbn());
        ps.setString(2, book.getTitle());
        ps.setString(3, book.getAuthor());
        ps.setString(4, book.getPublisher());
        if (book.getCategoryId() > 0) ps.setInt(5, book.getCategoryId());
        else ps.setNull(5, Types.INTEGER);
        ps.setInt(6, book.getPublishYear());
        ps.setInt(7, book.getTotalCopies());
        ps.setInt(8, book.getAvailableCopies());
        ps.setString(9, book.getLocation());
        ps.setString(10, book.getDescription());
    }

    private Book mapBook(ResultSet rs) throws SQLException {
        Book book = new Book();
        book.setId(rs.getInt("id"));
        book.setIsbn(rs.getString("isbn"));
        book.setTitle(rs.getString("title"));
        book.setAuthor(rs.getString("author"));
        book.setPublisher(rs.getString("publisher"));
        book.setCategoryId(rs.getInt("category_id"));
        book.setPublishYear(rs.getInt("publish_year"));
        book.setTotalCopies(rs.getInt("total_copies"));
        book.setAvailableCopies(rs.getInt("available_copies"));
        book.setLocation(rs.getString("location"));
        book.setDescription(rs.getString("description"));
        book.setCoverImage(rs.getString("cover_image"));
        try { book.setCategoryName(rs.getString("category_name")); } catch (SQLException ignored) {}
        return book;
    }
}
