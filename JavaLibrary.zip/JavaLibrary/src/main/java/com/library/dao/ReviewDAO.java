package com.library.dao;

import com.library.model.Review;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 图书评论数据访问对象
 */
public class ReviewDAO {
    private static final Logger logger = LogManager.getLogger(ReviewDAO.class);

    /** 查询某本书的所有评论 */
    public List<Review> findByBookId(int bookId) {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT r.*, u.username FROM reviews r LEFT JOIN users u ON r.user_id = u.id " +
                     "WHERE r.book_id = ? ORDER BY r.created_at DESC";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapReview(rs));
            }
        } catch (SQLException e) {
            logger.error("查询图书评论失败", e);
        }
        return list;
    }

    /** 查询用户的所有评论 */
    public List<Review> findByUserId(int userId) {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT r.*, u.username FROM reviews r LEFT JOIN users u ON r.user_id = u.id " +
                     "WHERE r.user_id = ? ORDER BY r.created_at DESC";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapReview(rs));
            }
        } catch (SQLException e) {
            logger.error("查询用户评论失败", e);
        }
        return list;
    }

    /** 获取图书平均评分 */
    public double getAverageRating(int bookId) {
        String sql = "SELECT AVG(rating) FROM reviews WHERE book_id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double avg = rs.getDouble(1);
                    return Math.round(avg * 10.0) / 10.0;
                }
            }
        } catch (SQLException e) {
            logger.error("查询平均评分失败", e);
        }
        return 0.0;
    }

    /** 检查用户是否已评论过该书 */
    public boolean hasUserReviewed(int userId, int bookId) {
        String sql = "SELECT COUNT(*) FROM reviews WHERE user_id = ? AND book_id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            logger.error("检查评论状态失败", e);
        }
        return false;
    }

    /** 插入评论 */
    public boolean insert(Review review) {
        String sql = "INSERT INTO reviews (user_id, book_id, rating, comment) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, review.getUserId());
            ps.setInt(2, review.getBookId());
            ps.setInt(3, review.getRating());
            ps.setString(4, review.getComment());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("插入评论失败", e);
        }
        return false;
    }

    /** 删除评论 */
    public boolean delete(int id) {
        String sql = "DELETE FROM reviews WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("删除评论失败", e);
        }
        return false;
    }

    private Review mapReview(ResultSet rs) throws SQLException {
        Review review = new Review();
        review.setId(rs.getInt("id"));
        review.setUserId(rs.getInt("user_id"));
        review.setBookId(rs.getInt("book_id"));
        review.setRating(rs.getInt("rating"));
        review.setComment(rs.getString("comment"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) review.setCreatedAt(ts.toLocalDateTime());
        try { review.setUsername(rs.getString("username")); } catch (SQLException ignored) {}
        return review;
    }
}
