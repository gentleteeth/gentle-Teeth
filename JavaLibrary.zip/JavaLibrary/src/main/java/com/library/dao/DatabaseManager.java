package com.library.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mindrot.jbcrypt.BCrypt;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;

/**
 * 数据库管理器 —— 单例模式
 * 负责SQLite数据库连接管理和初始化
 */
public class DatabaseManager {
    private static final Logger logger = LogManager.getLogger(DatabaseManager.class);
    private static DatabaseManager instance;
    private static final String DB_FILE = "library.db";
    private static final String INIT_SQL = "/init.sql";

    private DatabaseManager() {
        initializeDatabase();
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    /** 获取数据库连接 */
    public Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:" + DB_FILE);
        // 启用外键约束
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON");
        }
        return conn;
    }

    /** 初始化数据库：创建表并插入测试数据 */
    private void initializeDatabase() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            logger.error("SQLite JDBC驱动未找到", e);
            return;
        }

        File dbFile = new File(DB_FILE);
        boolean isNew = !dbFile.exists();

        if (isNew) {
            logger.info("数据库文件不存在，开始初始化...");
            executeInitScript();
            logger.info("数据库初始化完成");
        } else {
            // 检查是否需要更新
            ensureTablesExist();
        }
    }

    /** 执行初始化SQL脚本 */
    private void executeInitScript() {
        try (InputStream is = getClass().getResourceAsStream(INIT_SQL)) {
            if (is == null) {
                logger.warn("未找到init.sql，创建空表结构");
                createTables();
                return;
            }
            String sql = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            // 先移除所有注释行，再按分号拆分，避免注释导致有效语句被跳过
            String[] lines = sql.split("\n");
            StringBuilder cleaned = new StringBuilder();
            for (String line : lines) {
                String t = line.trim();
                if (!t.isEmpty() && !t.startsWith("--")) {
                    cleaned.append(line).append("\n");
                }
            }
            String[] statements = cleaned.toString().split(";");
            int executed = 0;
            try (Connection conn = getConnection();
                 Statement stmt = conn.createStatement()) {
                conn.setAutoCommit(false);
                for (String statement : statements) {
                    String trimmed = statement.trim();
                    if (!trimmed.isEmpty()) {
                        try {
                            stmt.execute(trimmed);
                            executed++;
                        } catch (SQLException e) {
                            logger.warn("执行SQL语句失败: {} - {}", trimmed.substring(0, Math.min(50, trimmed.length())), e.getMessage());
                        }
                    }
                }
                conn.commit();
                logger.info("成功执行 {} 条SQL语句", executed);
            }
        } catch (IOException e) {
            logger.warn("读取init.sql失败，创建空表结构", e);
            createTables();
        } catch (SQLException e) {
            logger.error("执行初始化脚本失败", e);
        }
    }

    /** 确保核心表存在 */
    private void ensureTablesExist() {
        String checkSql = "SELECT count(*) FROM sqlite_master WHERE type='table' AND name='users'";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(checkSql)) {
            if (rs.next() && rs.getInt(1) == 0) {
                logger.info("表不存在，初始化数据库...");
                executeInitScript();
            }
        } catch (SQLException e) {
            logger.error("检查表存在性失败", e);
        }
    }

    /** 创建基础表结构（不含测试数据） */
    private void createTables() {
        String sql = """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'member',
                email TEXT,
                phone TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT
            );
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                isbn TEXT UNIQUE,
                title TEXT NOT NULL,
                author TEXT,
                publisher TEXT,
                category_id INTEGER,
                publish_year INTEGER,
                total_copies INTEGER DEFAULT 1,
                available_copies INTEGER DEFAULT 1,
                location TEXT,
                description TEXT,
                cover_image TEXT,
                FOREIGN KEY (category_id) REFERENCES categories(id)
            );
            CREATE TABLE IF NOT EXISTS borrow_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                book_id INTEGER NOT NULL,
                borrow_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                due_date DATETIME NOT NULL,
                return_date DATETIME,
                status TEXT DEFAULT 'borrowed',
                fine_amount REAL DEFAULT 0.0,
                renewed INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (book_id) REFERENCES books(id)
            );
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                book_id INTEGER NOT NULL,
                reserve_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'pending',
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (book_id) REFERENCES books(id)
            );
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                book_id INTEGER NOT NULL,
                rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                comment TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (book_id) REFERENCES books(id)
            );
            """;
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            for (String s : sql.split(";")) {
                if (!s.trim().isEmpty()) {
                    stmt.execute(s.trim());
                }
            }
        } catch (SQLException e) {
            logger.error("创建表结构失败", e);
        }
    }
}
