package com.library.dao;

import com.library.model.Reservation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 图书预约数据访问对象
 */
public class ReservationDAO {
    private static final Logger logger = LogManager.getLogger(ReservationDAO.class);

    /** 查询所有预约 */
    public List<Reservation> findAll() {
        List<Reservation> list = new ArrayList<>();
        String sql = """
            SELECT r.*, u.username, b.title as book_title
            FROM reservations r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN books b ON r.book_id = b.id
            ORDER BY r.reserve_date DESC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapReservation(rs));
        } catch (SQLException e) {
            logger.error("查询所有预约失败", e);
        }
        return list;
    }

    /** 按用户查询预约 */
    public List<Reservation> findByUserId(int userId) {
        List<Reservation> list = new ArrayList<>();
        String sql = """
            SELECT r.*, u.username, b.title as book_title
            FROM reservations r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN books b ON r.book_id = b.id
            WHERE r.user_id = ? ORDER BY r.reserve_date DESC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapReservation(rs));
            }
        } catch (SQLException e) {
            logger.error("按用户查询预约失败", e);
        }
        return list;
    }

    /** 查询某本书的待处理预约 */
    public List<Reservation> findPendingByBookId(int bookId) {
        List<Reservation> list = new ArrayList<>();
        String sql = """
            SELECT r.*, u.username, b.title as book_title
            FROM reservations r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN books b ON r.book_id = b.id
            WHERE r.book_id = ? AND r.status = 'pending'
            ORDER BY r.reserve_date ASC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapReservation(rs));
            }
        } catch (SQLException e) {
            logger.error("查询待处理预约失败", e);
        }
        return list;
    }

    /** 检查用户是否已预约某书 */
    public boolean hasPendingReservation(int userId, int bookId) {
        String sql = "SELECT COUNT(*) FROM reservations WHERE user_id = ? AND book_id = ? AND status = 'pending'";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            logger.error("检查预约状态失败", e);
        }
        return false;
    }

    /** 插入预约 */
    public boolean insert(Reservation reservation) {
        String sql = "INSERT INTO reservations (user_id, book_id, status) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, reservation.getUserId());
            ps.setInt(2, reservation.getBookId());
            ps.setString(3, reservation.getStatus() != null ? reservation.getStatus() : "pending");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("插入预约失败", e);
        }
        return false;
    }

    /** 更新预约状态 */
    public boolean updateStatus(int id, String status) {
        String sql = "UPDATE reservations SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("更新预约状态失败", e);
        }
        return false;
    }

    /** 取消预约 */
    public boolean cancel(int id) {
        return updateStatus(id, "cancelled");
    }

    private Reservation mapReservation(ResultSet rs) throws SQLException {
        Reservation r = new Reservation();
        r.setId(rs.getInt("id"));
        r.setUserId(rs.getInt("user_id"));
        r.setBookId(rs.getInt("book_id"));
        Timestamp ts = rs.getTimestamp("reserve_date");
        if (ts != null) r.setReserveDate(ts.toLocalDateTime());
        r.setStatus(rs.getString("status"));
        try { r.setUsername(rs.getString("username")); } catch (SQLException ignored) {}
        try { r.setBookTitle(rs.getString("book_title")); } catch (SQLException ignored) {}
        return r;
    }
}
