package com.library.dao;

import com.library.model.BorrowRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 借阅记录数据访问对象
 */
public class BorrowRecordDAO {
    private static final Logger logger = LogManager.getLogger(BorrowRecordDAO.class);

    /** 查询所有借阅记录 */
    public List<BorrowRecord> findAll() {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = """
            SELECT br.*, u.username, b.title as book_title, b.isbn as book_isbn
            FROM borrow_records br
            LEFT JOIN users u ON br.user_id = u.id
            LEFT JOIN books b ON br.book_id = b.id
            ORDER BY br.id DESC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRecord(rs));
        } catch (SQLException e) {
            logger.error("查询所有借阅记录失败", e);
        }
        return list;
    }

    /** 根据用户ID查询借阅记录 */
    public List<BorrowRecord> findByUserId(int userId) {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = """
            SELECT br.*, u.username, b.title as book_title, b.isbn as book_isbn
            FROM borrow_records br
            LEFT JOIN users u ON br.user_id = u.id
            LEFT JOIN books b ON br.book_id = b.id
            WHERE br.user_id = ? ORDER BY br.id DESC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRecord(rs));
            }
        } catch (SQLException e) {
            logger.error("按用户查询借阅记录失败", e);
        }
        return list;
    }

    /** 查询当前借阅中的记录 */
    public List<BorrowRecord> findCurrentBorrows() {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = """
            SELECT br.*, u.username, b.title as book_title, b.isbn as book_isbn
            FROM borrow_records br
            LEFT JOIN users u ON br.user_id = u.id
            LEFT JOIN books b ON br.book_id = b.id
            WHERE br.status IN ('borrowed', 'overdue')
            ORDER BY br.due_date ASC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRecord(rs));
        } catch (SQLException e) {
            logger.error("查询当前借阅失败", e);
        }
        return list;
    }

    /** 查询用户当前借阅中的记录数 */
    public int countCurrentBorrowsByUser(int userId) {
        String sql = "SELECT COUNT(*) FROM borrow_records WHERE user_id = ? AND status IN ('borrowed', 'overdue')";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            logger.error("查询用户当前借阅数失败", e);
        }
        return 0;
    }

    /** 插入借阅记录 */
    public boolean insert(BorrowRecord record) {
        String sql = "INSERT INTO borrow_records (user_id, book_id, borrow_date, due_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, record.getUserId());
            ps.setInt(2, record.getBookId());
            ps.setTimestamp(3, Timestamp.valueOf(record.getBorrowDate()));
            ps.setTimestamp(4, Timestamp.valueOf(record.getDueDate()));
            ps.setString(5, record.getStatus() != null ? record.getStatus() : "borrowed");
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) record.setId(keys.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            logger.error("插入借阅记录失败", e);
        }
        return false;
    }

    /** 归还图书 */
    public boolean returnBook(int recordId, LocalDateTime returnDate, double fineAmount) {
        String sql = "UPDATE borrow_records SET return_date = ?, status = 'returned', fine_amount = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(returnDate));
            ps.setDouble(2, fineAmount);
            ps.setInt(3, recordId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("归还图书失败", e);
        }
        return false;
    }

    /** 续借（延长14天），DAO层也检查 renewed 状态防止重复续借 */
    public boolean renewBook(int recordId) {
        String sql = "UPDATE borrow_records SET due_date = datetime(due_date, '+14 days'), renewed = 1 WHERE id = ? AND renewed = 0";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recordId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("续借失败", e);
        }
        return false;
    }

    /** 更新逾期状态 */
    public void updateOverdueStatus() {
        String sql = "UPDATE borrow_records SET status = 'overdue' WHERE status = 'borrowed' AND due_date < datetime('now')";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement()) {
            int count = stmt.executeUpdate(sql);
            if (count > 0) logger.info("更新了 {} 条逾期记录", count);
        } catch (SQLException e) {
            logger.error("更新逾期状态失败", e);
        }
    }

    /** 根据ID查询 */
    public BorrowRecord findById(int id) {
        String sql = """
            SELECT br.*, u.username, b.title as book_title, b.isbn as book_isbn
            FROM borrow_records br
            LEFT JOIN users u ON br.user_id = u.id
            LEFT JOIN books b ON br.book_id = b.id
            WHERE br.id = ?
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRecord(rs);
            }
        } catch (SQLException e) {
            logger.error("查询借阅记录失败", e);
        }
        return null;
    }

    /** 查询用户是否借阅过某本书（包含已归还和正在借阅，用于评论权限验证） */
    public boolean hasUserBorrowedBook(int userId, int bookId) {
        String sql = "SELECT COUNT(*) FROM borrow_records WHERE user_id = ? AND book_id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            logger.error("查询用户借阅历史失败", e);
        }
        return false;
    }

    /** 检查用户是否有未归还的借阅记录（用于删除前校验） */
    public boolean hasActiveBorrowsByUser(int userId) {
        String sql = "SELECT COUNT(*) FROM borrow_records WHERE user_id = ? AND status IN ('borrowed', 'overdue')";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            logger.error("检查用户活跃借阅记录失败", e);
        }
        return false;
    }

    /** 查询与指定用户借过同一本书的其他用户借阅记录（用于推荐） */
    public List<BorrowRecord> findCoBorrows(int userId) {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = """
            SELECT DISTINCT br2.*, u.username, b.title as book_title, b.isbn as book_isbn
            FROM borrow_records br1
            JOIN borrow_records br2 ON br1.book_id = br2.book_id AND br1.user_id != br2.user_id
            LEFT JOIN users u ON br2.user_id = u.id
            LEFT JOIN books b ON br2.book_id = b.id
            WHERE br1.user_id = ?
            ORDER BY br2.id DESC
            LIMIT 30
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRecord(rs));
            }
        } catch (SQLException e) {
            logger.error("查询协同借阅记录失败", e);
        }
        return list;
    }

    /** 统计各分类借阅量 */
    public List<Object[]> getBorrowStatsByCategory() {
        List<Object[]> stats = new ArrayList<>();
        String sql = """
            SELECT c.name, COUNT(br.id)
            FROM borrow_records br
            JOIN books b ON br.book_id = b.id
            JOIN categories c ON b.category_id = c.id
            GROUP BY c.id
            ORDER BY COUNT(br.id) DESC
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                stats.add(new Object[]{rs.getString(1), rs.getInt(2)});
            }
        } catch (SQLException e) {
            logger.error("统计分类借阅量失败", e);
        }
        return stats;
    }

    /** 统计热门图书借阅排行 */
    public List<Object[]> getHotBookStats(int limit) {
        List<Object[]> stats = new ArrayList<>();
        String sql = """
            SELECT b.title, COUNT(br.id)
            FROM borrow_records br
            JOIN books b ON br.book_id = b.id
            GROUP BY b.id
            ORDER BY COUNT(br.id) DESC
            LIMIT ?
            """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    stats.add(new Object[]{rs.getString(1), rs.getInt(2)});
                }
            }
        } catch (SQLException e) {
            logger.error("统计热门图书失败", e);
        }
        return stats;
    }

    private BorrowRecord mapRecord(ResultSet rs) throws SQLException {
        BorrowRecord r = new BorrowRecord();
        r.setId(rs.getInt("id"));
        r.setUserId(rs.getInt("user_id"));
        r.setBookId(rs.getInt("book_id"));
        Timestamp borrowTs = rs.getTimestamp("borrow_date");
        if (borrowTs != null) r.setBorrowDate(borrowTs.toLocalDateTime());
        Timestamp dueTs = rs.getTimestamp("due_date");
        if (dueTs != null) r.setDueDate(dueTs.toLocalDateTime());
        Timestamp returnTs = rs.getTimestamp("return_date");
        if (returnTs != null) r.setReturnDate(returnTs.toLocalDateTime());
        r.setStatus(rs.getString("status"));
        r.setFineAmount(rs.getDouble("fine_amount"));
        r.setRenewed(rs.getInt("renewed"));
        try { r.setUsername(rs.getString("username")); } catch (SQLException ignored) {}
        try { r.setBookTitle(rs.getString("book_title")); } catch (SQLException ignored) {}
        try { r.setBookIsbn(rs.getString("book_isbn")); } catch (SQLException ignored) {}
        return r;
    }
}
