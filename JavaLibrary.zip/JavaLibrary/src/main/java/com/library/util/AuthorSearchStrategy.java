package com.library.util;

import com.library.model.Book;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 按作者搜索策略
 */
public class AuthorSearchStrategy implements SearchStrategy {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        String kw = keyword.toLowerCase();
        return books.stream()
                .filter(b -> b.getAuthor() != null && b.getAuthor().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}
