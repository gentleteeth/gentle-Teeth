package com.library.util;

import com.library.model.*;

/**
 * 用户工厂 —— 工厂模式
 * 根据角色类型创建对应的用户子类对象
 */
public class UserFactory {

    /** 根据角色创建用户对象 */
    public static User createUser(String role, int id, String username, String password,
                                   String email, String phone) {
        return switch (role.toLowerCase()) {
            case "admin" -> new Admin(id, username, password, email, phone);
            case "librarian" -> new Librarian(id, username, password, email, phone);
            case "member" -> new Member(id, username, password, email, phone);
            default -> new Member(id, username, password, email, phone);
        };
    }

    /** 从已有User数据创建具体子类对象 */
    public static User createFromData(int id, String username, String password, String role,
                                       String email, String phone) {
        return createUser(role, id, username, password, email, phone);
    }
}
