package com.library.util;

import com.library.model.Book;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 按分类搜索策略
 */
public class CategorySearchStrategy implements SearchStrategy {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        String kw = keyword.toLowerCase();
        return books.stream()
                .filter(b -> b.getCategoryName() != null && b.getCategoryName().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}
