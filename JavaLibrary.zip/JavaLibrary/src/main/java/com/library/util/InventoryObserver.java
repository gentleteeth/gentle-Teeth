package com.library.util;

/**
 * 库存观察者接口 —— 观察者模式
 * 当图书库存发生变化时，实现此接口的视图将收到通知
 */
public interface InventoryObserver {
    /** 库存变化时调用 */
    void onInventoryChanged();
}
