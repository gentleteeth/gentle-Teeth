package com.library.util;

import com.library.model.Book;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 按书名搜索策略
 */
public class TitleSearchStrategy implements SearchStrategy {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        String kw = keyword.toLowerCase();
        return books.stream()
                .filter(b -> b.getTitle() != null && b.getTitle().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}
