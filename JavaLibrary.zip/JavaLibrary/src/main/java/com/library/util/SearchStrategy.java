package com.library.util;

import com.library.model.Book;
import java.util.List;

/**
 * 搜索策略接口 —— 策略模式
 */
public interface SearchStrategy {
    /** 根据关键词搜索图书 */
    List<Book> search(List<Book> books, String keyword);
}
