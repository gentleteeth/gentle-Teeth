package com.library.util;

import com.library.model.Book;

/**
 * 图书装饰器抽象类 —— 装饰器模式
 * 动态为图书对象添加额外信息
 */
public abstract class BookDecorator {
    protected Book book;

    public BookDecorator(Book book) {
        this.book = book;
    }

    public Book getBook() { return book; }

    /** 获取附加信息描述 */
    public abstract String getExtraInfo();

    /** 获取装饰标签 */
    public abstract String getTag();
}
