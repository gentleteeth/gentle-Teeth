package com.library.util;

import com.library.model.Book;
import com.library.model.BorrowRecord;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Excel导出工具类 —— 使用Apache POI
 */
public class ExportUtil {
    private static final Logger logger = LogManager.getLogger(ExportUtil.class);
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** 导出图书列表到Excel */
    public static void exportBooks(List<Book> books, File file) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("图书列表");
            // 表头样式
            CellStyle headerStyle = createHeaderStyle(workbook);

            Row header = sheet.createRow(0);
            String[] columns = {"ID", "ISBN", "书名", "作者", "出版社", "分类", "出版年份",
                    "总册数", "可借册数", "位置", "简介"};
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowIdx = 1;
            for (Book b : books) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(b.getId());
                row.createCell(1).setCellValue(b.getIsbn());
                row.createCell(2).setCellValue(b.getTitle());
                row.createCell(3).setCellValue(b.getAuthor());
                row.createCell(4).setCellValue(b.getPublisher());
                row.createCell(5).setCellValue(b.getCategoryName());
                row.createCell(6).setCellValue(b.getPublishYear());
                row.createCell(7).setCellValue(b.getTotalCopies());
                row.createCell(8).setCellValue(b.getAvailableCopies());
                row.createCell(9).setCellValue(b.getLocation());
                row.createCell(10).setCellValue(b.getDescription());
            }

            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }
            logger.info("图书列表已导出到: {}", file.getAbsolutePath());
        }
    }

    /** 导出借阅记录到Excel */
    public static void exportBorrowRecords(List<BorrowRecord> records, File file) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("借阅记录");
            CellStyle headerStyle = createHeaderStyle(workbook);

            Row header = sheet.createRow(0);
            String[] columns = {"ID", "读者", "图书", "ISBN", "借阅日期", "应还日期",
                    "归还日期", "状态", "罚款金额(元)", "是否续借"};
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowIdx = 1;
            for (BorrowRecord r : records) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(r.getId());
                row.createCell(1).setCellValue(r.getUsername());
                row.createCell(2).setCellValue(r.getBookTitle());
                row.createCell(3).setCellValue(r.getBookIsbn());
                row.createCell(4).setCellValue(r.getBorrowDate() != null ? r.getBorrowDate().format(dtf) : "");
                row.createCell(5).setCellValue(r.getDueDate() != null ? r.getDueDate().format(dtf) : "");
                row.createCell(6).setCellValue(r.getReturnDate() != null ? r.getReturnDate().format(dtf) : "未归还");
                row.createCell(7).setCellValue(getStatusText(r.getStatus()));
                row.createCell(8).setCellValue(r.getFineAmount());
                row.createCell(9).setCellValue(r.getRenewed() == 1 ? "是" : "否");
            }

            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }
            logger.info("借阅记录已导出到: {}", file.getAbsolutePath());
        }
    }

    /** 导出罚款明细到Excel */
    public static void exportFineDetails(List<BorrowRecord> records, File file) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("罚款明细");
            CellStyle headerStyle = createHeaderStyle(workbook);

            Row header = sheet.createRow(0);
            String[] columns = {"ID", "读者", "图书", "应还日期", "归还日期", "逾期天数", "罚款金额(元)"};
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowIdx = 1;
            double totalFine = 0;
            for (BorrowRecord r : records) {
                if (r.getFineAmount() > 0) {
                    Row row = sheet.createRow(rowIdx++);
                    row.createCell(0).setCellValue(r.getId());
                    row.createCell(1).setCellValue(r.getUsername());
                    row.createCell(2).setCellValue(r.getBookTitle());
                    row.createCell(3).setCellValue(r.getDueDate() != null ? r.getDueDate().format(dtf) : "");
                    row.createCell(4).setCellValue(r.getReturnDate() != null ? r.getReturnDate().format(dtf) : "");
                    row.createCell(5).setCellValue(r.getOverdueDays());
                    row.createCell(6).setCellValue(r.getFineAmount());
                    totalFine += r.getFineAmount();
                }
            }
            // 合计行
            Row totalRow = sheet.createRow(rowIdx);
            totalRow.createCell(5).setCellValue("合计：");
            totalRow.createCell(6).setCellValue(totalFine);

            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }
            logger.info("罚款明细已导出到: {}", file.getAbsolutePath());
        }
    }

    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    private static String getStatusText(String status) {
        return switch (status) {
            case "borrowed" -> "借阅中";
            case "returned" -> "已归还";
            case "overdue" -> "已逾期";
            default -> status;
        };
    }
}
