package com.library.util;

import com.library.model.Book;

/**
 * 推荐图书装饰器 —— 装饰器模式
 * 为图书添加推荐理由标签
 */
public class RecommendedBookDecorator extends BookDecorator {
    private final String reason;

    public RecommendedBookDecorator(Book book, String reason) {
        super(book);
        this.reason = reason;
    }

    @Override
    public String getExtraInfo() {
        return "[推荐] " + book.getTitle() + " —— " + reason;
    }

    @Override
    public String getTag() {
        return "推荐";
    }
}
