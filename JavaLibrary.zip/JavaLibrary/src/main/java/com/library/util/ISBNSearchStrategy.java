package com.library.util;

import com.library.model.Book;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 按ISBN搜索策略
 */
public class ISBNSearchStrategy implements SearchStrategy {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        return books.stream()
                .filter(b -> b.getIsbn() != null && b.getIsbn().contains(keyword.trim()))
                .collect(Collectors.toList());
    }
}
