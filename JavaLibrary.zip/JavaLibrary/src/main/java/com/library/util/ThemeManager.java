package com.library.util;

import java.io.*;
import java.nio.file.*;
import java.util.prefs.Preferences;

/**
 * 主题管理器 —— 支持深色/浅色主题切换并持久化状态
 */
public class ThemeManager {
    private static ThemeManager instance;
    private boolean darkMode;
    private static final String LIGHT_THEME_CSS = "/light-theme.css";
    private static final String DARK_THEME_CSS = "/dark-theme.css";
    private static final String PREF_KEY = "dark_mode";

    private ThemeManager() {
        // 从Preferences读取上次的主题设置
        Preferences prefs = Preferences.userNodeForPackage(ThemeManager.class);
        darkMode = prefs.getBoolean(PREF_KEY, false);
    }

    public static synchronized ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    public boolean isDarkMode() { return darkMode; }

    public void setDarkMode(boolean darkMode) {
        this.darkMode = darkMode;
        Preferences prefs = Preferences.userNodeForPackage(ThemeManager.class);
        prefs.putBoolean(PREF_KEY, darkMode);
    }

    public void toggle() {
        setDarkMode(!darkMode);
    }

    /** 获取当前主题CSS路径 */
    public String getCurrentThemePath() {
        return darkMode ? DARK_THEME_CSS : LIGHT_THEME_CSS;
    }

    /** 获取当前主题名称 */
    public String getCurrentThemeName() {
        return darkMode ? "深色主题" : "浅色主题";
    }
}
