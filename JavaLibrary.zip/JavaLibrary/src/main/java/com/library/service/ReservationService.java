package com.library.service;

import com.library.dao.ReservationDAO;
import com.library.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * 预约服务 —— 处理图书预约、取消预约、库存补充通知
 */
public class ReservationService {
    private static final Logger logger = LogManager.getLogger(ReservationService.class);
    private final ReservationDAO reservationDAO = new ReservationDAO();
    private final BookService bookService;
    private final NotificationService notificationService;

    public ReservationService(BookService bookService, NotificationService notificationService) {
        this.bookService = bookService;
        this.notificationService = notificationService;
    }

    /** 预约图书 */
    public String reserveBook(User user, int bookId) {
        Book book = bookService.getBookById(bookId);
        if (book == null) return "图书不存在";

        // 如果有库存，不需要预约
        if (book.isAvailable()) {
            return "该书当前有库存，可直接借阅";
        }

        // 检查是否已预约
        if (reservationDAO.hasPendingReservation(user.getId(), bookId)) {
            return "您已预约过该书，请勿重复预约";
        }

        Reservation reservation = new Reservation();
        reservation.setUserId(user.getId());
        reservation.setBookId(bookId);
        reservation.setStatus("pending");

        if (reservationDAO.insert(reservation)) {
            notificationService.notify(user, "预约成功",
                    "《" + book.getTitle() + "》预约成功，库存补充后将通知您");
            logger.info("用户 {} 预约了《{}》", user.getUsername(), book.getTitle());
            return "预约成功，库存补充后将通知您";
        }
        return "预约失败，请重试";
    }

    /** 取消预约 */
    public String cancelReservation(int reservationId) {
        if (reservationDAO.cancel(reservationId)) {
            logger.info("预约取消 id={}", reservationId);
            return "预约已取消";
        }
        return "取消预约失败";
    }

    /** 当图书库存补充时，通知预约用户 */
    public void notifyReservedUsers(int bookId) {
        List<Reservation> pending = reservationDAO.findPendingByBookId(bookId);
        Book book = bookService.getBookById(bookId);
        if (book == null || pending.isEmpty()) return;

        for (Reservation r : pending) {
            notificationService.notifyById(r.getUserId(), "预约到书通知",
                    "您预约的《" + book.getTitle() + "》已有库存，请尽快到馆借阅");
            reservationDAO.updateStatus(r.getId(), "fulfilled");
        }
        logger.info("通知了 {} 位预约用户，图书《{}》已到库", pending.size(), book.getTitle());
    }

    /** 获取所有预约 */
    public List<Reservation> getAllReservations() {
        return reservationDAO.findAll();
    }

    /** 获取用户预约 */
    public List<Reservation> getUserReservations(int userId) {
        return reservationDAO.findByUserId(userId);
    }

    /** 获取某本书的待处理预约 */
    public List<Reservation> getPendingByBook(int bookId) {
        return reservationDAO.findPendingByBookId(bookId);
    }
}
