package com.library.service;

import com.library.dao.BorrowRecordDAO;
import com.library.model.BorrowRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * 报表服务 —— 提供统计数据
 */
public class ReportService {
    private static final Logger logger = LogManager.getLogger(ReportService.class);
    private final BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();

    /** 获取分类借阅统计（饼图数据） */
    public List<Object[]> getCategoryStats() {
        return borrowRecordDAO.getBorrowStatsByCategory();
    }

    /** 获取热门图书统计（柱状图数据） */
    public List<Object[]> getHotBookStats(int limit) {
        return borrowRecordDAO.getHotBookStats(limit);
    }

    /** 获取罚款汇总 */
    public double getTotalFines() {
        List<BorrowRecord> records = borrowRecordDAO.findAll();
        return records.stream().mapToDouble(BorrowRecord::getFineAmount).sum();
    }
}
