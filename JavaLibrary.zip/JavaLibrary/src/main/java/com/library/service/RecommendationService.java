package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.BorrowRecordDAO;
import com.library.model.Book;
import com.library.model.BorrowRecord;
import com.library.util.RecommendedBookDecorator;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 图书推荐服务 —— 基于简单协同过滤思想
 * 找出与当前用户借阅过同一本书的其他用户，推荐他们借阅过的其他图书
 */
public class RecommendationService {
    private final BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();
    private final BookDAO bookDAO = new BookDAO();

    /**
     * 为用户推荐图书
     * @param userId 当前用户ID
     * @param limit 推荐数量上限
     * @return 带推荐理由的装饰图书列表
     */
    public List<RecommendedBookDecorator> recommendForUser(int userId, int limit) {
        // 获取与当前用户借阅过同一本书的其他用户的借阅记录
        List<BorrowRecord> coBorrows = borrowRecordDAO.findCoBorrows(userId);
        if (coBorrows.isEmpty()) return List.of();

        // 预先获取当前用户所有借阅记录，避免在循环内重复查询（N+1问题）
        List<BorrowRecord> userRecords = borrowRecordDAO.findByUserId(userId);
        Set<Integer> userBookIds = new HashSet<>();
        Set<Integer> userCurrentBookIds = new HashSet<>();
        for (BorrowRecord r : userRecords) {
            userBookIds.add(r.getBookId()); // 所有曾借阅过的书
            if ("borrowed".equals(r.getStatus()) || "overdue".equals(r.getStatus())) {
                userCurrentBookIds.add(r.getBookId()); // 当前正在借阅的书
            }
        }

        // 统计每本书被共同借阅者借阅的次数
        Map<Integer, Integer> bookCount = new HashMap<>();
        Map<Integer, Set<String>> bookReasons = new HashMap<>(); // 记录推荐理由

        for (BorrowRecord record : coBorrows) {
            int bookId = record.getBookId();
            // 排除当前用户已借阅的书和正在借阅的书（使用预加载集合，避免循环内查库）
            if (userBookIds.contains(bookId) || userCurrentBookIds.contains(bookId)) continue;

            bookCount.merge(bookId, 1, Integer::sum);
            bookReasons.computeIfAbsent(bookId, k -> new HashSet<>())
                    .add(record.getUsername());
        }

        // 按借阅次数降序排列
        List<Map.Entry<Integer, Integer>> sorted = bookCount.entrySet().stream()
                .sorted(Map.Entry.<Integer, Integer>comparingByValue().reversed())
                .limit(limit)
                .toList();

        List<RecommendedBookDecorator> result = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : sorted) {
            Book book = bookDAO.findById(entry.getKey());
            if (book != null && book.isAvailable()) {
                Set<String> users = bookReasons.get(entry.getKey());
                String reason = users.size() + "位读者也借阅了此书";
                result.add(new RecommendedBookDecorator(book, reason));
            }
        }
        return result;
    }
}
