package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.CategoryDAO;
import com.library.model.Book;
import com.library.model.Category;
import com.library.util.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * 图书服务 —— 观察者模式中的被观察者
 */
public class BookService {
    private static final Logger logger = LogManager.getLogger(BookService.class);
    private final BookDAO bookDAO = new BookDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final List<InventoryObserver> observers = new ArrayList<>();
    private SearchStrategy searchStrategy = new TitleSearchStrategy();

    /** 注册库存观察者 */
    public void addObserver(InventoryObserver observer) {
        observers.add(observer);
    }

    /** 移除库存观察者 */
    public void removeObserver(InventoryObserver observer) {
        observers.remove(observer);
    }

    /** 通知所有观察者 */
    private void notifyObservers() {
        for (InventoryObserver obs : observers) {
            obs.onInventoryChanged();
        }
    }

    /** 获取所有图书 */
    public List<Book> getAllBooks() {
        return bookDAO.findAll();
    }

    /** 获取所有分类 */
    public List<Category> getAllCategories() {
        return categoryDAO.findAll();
    }

    /** 根据ID获取图书 */
    public Book getBookById(int id) {
        return bookDAO.findById(id);
    }

    /** 根据ISBN获取图书 */
    public Book getBookByIsbn(String isbn) {
        return bookDAO.findByIsbn(isbn);
    }

    /** 添加图书 */
    public boolean addBook(Book book) {
        boolean result = bookDAO.insert(book);
        if (result) {
            notifyObservers();
            logger.info("新增图书: {}", book.getTitle());
        }
        return result;
    }

    /** 更新图书 */
    public boolean updateBook(Book book) {
        boolean result = bookDAO.update(book);
        if (result) {
            notifyObservers();
            logger.info("更新图书: {}", book.getTitle());
        }
        return result;
    }

    /** 删除图书（删除前检查是否有未归还的借阅记录） */
    public boolean deleteBook(int id) {
        if (bookDAO.hasActiveBorrows(id)) {
            logger.warn("无法删除图书 id={}，存在未归还的借阅记录", id);
            return false;
        }
        boolean result = bookDAO.delete(id);
        if (result) {
            notifyObservers();
            logger.info("删除图书 id={}", id);
        }
        return result;
    }

    /** 借出图书（减库存），使用原子操作避免竞态条件 */
    public boolean borrowBook(int bookId) {
        boolean result = bookDAO.atomicDecrementAvailable(bookId);
        if (result) notifyObservers();
        return result;
    }

    /** 归还图书（加库存），使用原子操作避免超出总库存 */
    public boolean returnBook(int bookId) {
        boolean result = bookDAO.atomicIncrementAvailable(bookId);
        if (result) notifyObservers();
        return result;
    }

    /** 搜索图书 */
    public List<Book> searchBooks(String keyword, Integer categoryId, String searchType) {
        return bookDAO.search(keyword, categoryId, searchType);
    }

    /** 使用策略模式搜索 */
    public List<Book> searchWithStrategy(String keyword) {
        List<Book> allBooks = bookDAO.findAll();
        return searchStrategy.search(allBooks, keyword);
    }

    /** 设置搜索策略 */
    public void setSearchStrategy(SearchStrategy strategy) {
        this.searchStrategy = strategy;
    }

    /** 按分类获取图书 */
    public List<Book> getBooksByCategory(int categoryId) {
        return bookDAO.findByCategory(categoryId);
    }

    /** 获取热门图书 */
    public List<Book> getHotBooks(int limit) {
        return bookDAO.findHotBooks(limit);
    }

    /** 获取图书总数 */
    public int getTotalBookCount() {
        return bookDAO.getTotalCount();
    }

    /** 获取图书分类 */
    public Category getCategoryById(int id) {
        return categoryDAO.findById(id);
    }

    /** 添加分类 */
    public boolean addCategory(Category category) {
        return categoryDAO.insert(category);
    }

    /** 更新分类 */
    public boolean updateCategory(Category category) {
        return categoryDAO.update(category);
    }

    /** 删除分类（删除前检查是否有关联图书） */
    public boolean deleteCategory(int id) {
        if (categoryDAO.hasBooks(id)) {
            logger.warn("无法删除分类 id={}，该分类下仍有关联图书", id);
            return false;
        }
        return categoryDAO.delete(id);
    }
}
