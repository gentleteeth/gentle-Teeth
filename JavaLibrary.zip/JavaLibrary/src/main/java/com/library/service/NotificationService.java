package com.library.service;

import com.library.model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 通知服务 —— 模拟邮件/系统通知
 */
public class NotificationService {
    private static final Logger logger = LogManager.getLogger(NotificationService.class);

    /** 通知记录内部类 */
    public static class Notification {
        public int userId;
        public String title;
        public String message;
        public String type; // success / warning / error / info
        public LocalDateTime time;

        public Notification(int userId, String title, String message, String type) {
            this.userId = userId;
            this.title = title;
            this.message = message;
            this.type = type;
            this.time = LocalDateTime.now();
        }
    }

    private static final int MAX_NOTIFICATIONS = 500; // 通知列表上限，防止内存泄漏
    private final List<Notification> notifications = new ArrayList<>();
    // 用于UI回调的监听器
    private NotificationListener listener;

    public interface NotificationListener {
        void onNotification(Notification notification);
    }

    public void setListener(NotificationListener listener) {
        this.listener = listener;
    }

    /** 发送通知给指定用户 */
    public void notify(User user, String title, String message) {
        notify(user.getId(), title, message, "info");
    }

    /** 通过用户ID发送通知 */
    public void notifyById(int userId, String title, String message) {
        notify(userId, title, message, "info");
    }

    /** 发送带类型的通知 */
    public void notify(int userId, String title, String message, String type) {
        Notification notification = new Notification(userId, title, message, type);
        notifications.add(notification);
        // 超过上限时移除最旧的通知
        while (notifications.size() > MAX_NOTIFICATIONS) {
            notifications.remove(0);
        }
        logger.info("[通知] 用户id={}, 标题=\"{}\", 内容=\"{}\"", userId, title, message);

        if (listener != null) {
            listener.onNotification(notification);
        }
    }

    /** 获取所有通知 */
    public List<Notification> getNotifications() {
        return notifications;
    }

    /** 获取指定用户的通知 */
    public List<Notification> getNotificationsForUser(int userId) {
        return notifications.stream()
                .filter(n -> n.userId == userId)
                .toList();
    }

    /** 清空通知 */
    public void clear() {
        notifications.clear();
    }
}
