package com.library.service;

import com.library.dao.BorrowRecordDAO;
import com.library.dao.UserDAO;
import com.library.model.User;
import com.library.util.UserFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mindrot.jbcrypt.BCrypt;

import java.util.List;

/**
 * 用户服务 —— 处理登录、注册、用户管理等业务逻辑
 */
public class UserService {
    private static final Logger logger = LogManager.getLogger(UserService.class);
    private final UserDAO userDAO = new UserDAO();
    private final BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();
    private User currentUser; // 当前登录用户（会话）

    /** 用户登录，验证用户名和密码 */
    public User login(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user == null) {
            logger.info("登录失败：用户 {} 不存在", username);
            return null;
        }
        // 兼容明文密码和BCrypt哈希
        String storedPwd = user.getPassword();
        boolean ok;
        if (storedPwd.startsWith("$2a$")) {
            ok = BCrypt.checkpw(password, storedPwd);
        } else {
            // 明文密码直接比对，通过后自动升级为BCrypt哈希
            ok = storedPwd.equals(password);
            if (ok) {
                String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
                userDAO.updatePassword(user.getId(), hashed);
                user.setPassword(hashed);
                logger.info("用户 {} 密码已升级为BCrypt哈希", username);
            }
        }
        if (ok) {
            currentUser = user;
            logger.info("用户 {} ({}) 登录成功", username, user.getRoleDisplayName());
            return user;
        }
        logger.info("登录失败：用户 {} 密码错误", username);
        return null;
    }

    /** 用户注册 */
    public boolean register(String username, String password, String email, String phone) {
        if (userDAO.findByUsername(username) != null) {
            return false; // 用户名已存在
        }
        String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
        User user = UserFactory.createUser("member", 0, username, hashed, email, phone);
        return userDAO.insert(user);
    }

    /** 退出登录 */
    public void logout() {
        currentUser = null;
    }

    /** 获取当前登录用户 */
    public User getCurrentUser() { return currentUser; }

    /** 是否已登录 */
    public boolean isLoggedIn() { return currentUser != null; }

    /** 获取所有用户 */
    public List<User> getAllUsers() { return userDAO.findAll(); }

    /** 按角色查询用户 */
    public List<User> getUsersByRole(String role) { return userDAO.findByRole(role); }

    /** 搜索用户 */
    public List<User> searchUsers(String keyword) { return userDAO.search(keyword); }

    /** 添加用户 */
    public boolean addUser(String username, String password, String role, String email, String phone) {
        if (userDAO.findByUsername(username) != null) return false;
        String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
        User user = UserFactory.createUser(role, 0, username, hashed, email, phone);
        return userDAO.insert(user);
    }

    /** 更新用户，防止将明文密码覆盖到数据库 */
    public boolean updateUser(User user) {
        // 若密码字段非空且不是BCrypt哈希格式，则自动哈希
        String pwd = user.getPassword();
        if (pwd != null && !pwd.isBlank() && !pwd.startsWith("$2a$")) {
            user.setPassword(BCrypt.hashpw(pwd, BCrypt.gensalt()));
        }
        return userDAO.update(user);
    }

    /** 删除用户（删除前检查是否有未归还的借阅记录） */
    public boolean deleteUser(int id) {
        if (borrowRecordDAO.hasActiveBorrowsByUser(id)) {
            logger.warn("无法删除用户 id={}，存在未归还的借阅记录", id);
            return false;
        }
        return userDAO.delete(id);
    }

    /** 修改密码 */
    public boolean changePassword(int userId, String newPassword) {
        String hashed = BCrypt.hashpw(newPassword, BCrypt.gensalt());
        return userDAO.updatePassword(userId, hashed);
    }

    /** 根据ID获取用户 */
    public User getUserById(int id) {
        return userDAO.findById(id);
    }
}
