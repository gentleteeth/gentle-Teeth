package com.library.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 数据库备份与恢复服务
 */
public class BackupService {
    private static final Logger logger = LogManager.getLogger(BackupService.class);
    private static final String DB_FILE = "library.db";

    /** 导出数据库为SQL文件 */
    public boolean backupToSql(File outputFile) {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + DB_FILE);
             PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                     new FileOutputStream(outputFile), "UTF-8"))) {

            writer.println("-- 图书管理系统数据库备份");
            writer.println("-- 备份时间: " + LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            writer.println();

            // 导出各表数据
            String[] tables = {"users", "categories", "books", "borrow_records", "reservations", "reviews"};
            for (String table : tables) {
                exportTable(conn, writer, table);
            }

            logger.info("数据库已备份到: {}", outputFile.getAbsolutePath());
            return true;
        } catch (Exception e) {
            logger.error("数据库备份失败", e);
            return false;
        }
    }

    /** 从SQL文件恢复数据库（清空+导入在同一事务内完成，保证原子性） */
    public boolean restoreFromSql(File inputFile) {
        // 先备份当前数据库
        File backupDir = new File("backups");
        if (!backupDir.exists()) backupDir.mkdirs();
        File autoBackup = new File(backupDir, "auto_backup_before_restore_" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".db");
        try {
            Files.copy(Path.of(DB_FILE), autoBackup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            logger.info("恢复前已自动备份到: {}", autoBackup.getAbsolutePath());
        } catch (IOException e) {
            logger.error("自动备份失败", e);
            return false;
        }

        // 清空 + 导入在同一事务内完成，失败时整体回滚，避免数据库半空
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + DB_FILE);
             Statement stmt = conn.createStatement()) {
            conn.setAutoCommit(false);

            // 清空所有表数据
            String[] tables = {"reviews", "reservations", "borrow_records", "books", "categories", "users"};
            for (String table : tables) {
                stmt.execute("DELETE FROM " + table);
            }
            logger.info("已清空数据库，开始恢复...");

            // 执行SQL文件
            String sql = Files.readString(inputFile.toPath());
            // 先移除所有注释行，再按分号拆分，避免注释导致有效语句被跳过
            String[] lines = sql.split("\n");
            StringBuilder cleaned = new StringBuilder();
            for (String line : lines) {
                String t = line.trim();
                if (!t.isEmpty() && !t.startsWith("--")) {
                    cleaned.append(line).append("\n");
                }
            }
            String[] statements = cleaned.toString().split(";");
            int successCount = 0;
            for (String statement : statements) {
                String trimmed = statement.trim();
                if (!trimmed.isEmpty() && !trimmed.startsWith("--")) {
                    try {
                        stmt.execute(trimmed);
                        successCount++;
                    } catch (SQLException e) {
                        logger.warn("执行SQL失败(跳过): {}", e.getMessage());
                    }
                }
            }
            conn.commit();
            logger.info("数据库已从 {} 恢复，成功执行 {} 条语句", inputFile.getAbsolutePath(), successCount);
            return true;
        } catch (Exception e) {
            logger.error("数据库恢复失败，回滚事务", e);
            // 事务失败时尝试回滚
            try (Connection rollbackConn = DriverManager.getConnection("jdbc:sqlite:" + DB_FILE);
                 Statement rollbackStmt = rollbackConn.createStatement()) {
                rollbackConn.setAutoCommit(false);
                rollbackStmt.execute("ROLLBACK");
            } catch (SQLException ignored) {}
            // 从自动备份文件还原
            try {
                Files.copy(autoBackup.toPath(), Path.of(DB_FILE), StandardCopyOption.REPLACE_EXISTING);
                logger.info("已从自动备份恢复数据库");
            } catch (IOException ex) {
                logger.error("自动恢复也失败了", ex);
            }
            return false;
        }
    }

    private void exportTable(Connection conn, PrintWriter writer, String table) throws SQLException {
        writer.println("-- 表: " + table);
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM " + table)) {

            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();

            while (rs.next()) {
                StringBuilder sb = new StringBuilder("INSERT OR IGNORE INTO " + table + " (");
                for (int i = 1; i <= colCount; i++) {
                    if (i > 1) sb.append(", ");
                    sb.append(meta.getColumnName(i));
                }
                sb.append(") VALUES (");
                for (int i = 1; i <= colCount; i++) {
                    if (i > 1) sb.append(", ");
                    String val = rs.getString(i);
                    if (val == null) {
                        sb.append("NULL");
                    } else {
                        sb.append("'").append(val.replace("'", "''")).append("'");
                    }
                }
                sb.append(");");
                writer.println(sb.toString());
            }
        }
        writer.println();
    }
}
