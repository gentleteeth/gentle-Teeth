package com.library.service;

import com.library.dao.BorrowRecordDAO;
import com.library.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 借阅服务 —— 处理借书、还书、续借等核心业务
 */
public class BorrowService {
    private static final Logger logger = LogManager.getLogger(BorrowService.class);
    private final BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();
    private final BookService bookService;
    private final NotificationService notificationService;
    private ReservationService reservationService; // 延迟注入，避免循环依赖

    public BorrowService(BookService bookService, NotificationService notificationService) {
        this.bookService = bookService;
        this.notificationService = notificationService;
    }

    /** 注入预约服务（由调用者在构建后设置） */
    public void setReservationService(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /** 借书 */
    public String borrowBook(User user, Book book) {
        // 更新逾期状态
        borrowRecordDAO.updateOverdueStatus();

        // 检查库存
        if (!book.isAvailable()) {
            return "该书暂无库存，可进行预约";
        }

        // 检查用户借阅数量限制
        int currentBorrows = borrowRecordDAO.countCurrentBorrowsByUser(user.getId());
        int maxLimit = (user instanceof Member) ? ((Member) user).getMaxBorrowLimit() : 10;
        if (currentBorrows >= maxLimit) {
            return "借阅数量已达上限(" + maxLimit + "本)，请先归还部分图书";
        }

        // 检查是否已借阅同一本书
        List<BorrowRecord> currentList = borrowRecordDAO.findByUserId(user.getId());
        for (BorrowRecord br : currentList) {
            if (br.getBookId() == book.getId() && ("borrowed".equals(br.getStatus()) || "overdue".equals(br.getStatus()))) {
                return "您已借阅该书，请勿重复借阅";
            }
        }

        // 创建借阅记录
        BorrowRecord record = new BorrowRecord();
        record.setUserId(user.getId());
        record.setBookId(book.getId());
        record.setBorrowDate(LocalDateTime.now());
        record.setDueDate(LocalDateTime.now().plusDays(14)); // 借阅期限14天
        record.setStatus("borrowed");

        if (borrowRecordDAO.insert(record)) {
            // 扣减库存，若失败则补偿删除借阅记录
            if (!bookService.borrowBook(book.getId())) {
                logger.error("扣减库存失败，回滚借阅记录 id={}", record.getId());
                // 补偿操作：将刚插入的记录标记为已归还，保持数据一致
                borrowRecordDAO.returnBook(record.getId(), LocalDateTime.now(), 0);
                return "借阅操作失败（库存不足），请重试";
            }
            notificationService.notify(user, "借书成功",
                    "《" + book.getTitle() + "》借阅成功，应还日期：" + record.getDueDate().toLocalDate());
            logger.info("用户 {} 借阅了《{}》", user.getUsername(), book.getTitle());
            return "SUCCESS";
        }
        return "借阅操作失败，请重试";
    }

    /** 还书 */
    public String returnBook(int recordId) {
        BorrowRecord record = borrowRecordDAO.findById(recordId);
        if (record == null) return "借阅记录不存在";
        if ("returned".equals(record.getStatus())) return "该书已归还";

        LocalDateTime now = LocalDateTime.now();
        double fine = record.calculateFine();

        if (borrowRecordDAO.returnBook(recordId, now, fine)) {
            bookService.returnBook(record.getBookId());

            String msg = "《" + record.getBookTitle() + "》归还成功";
            if (fine > 0) msg += "，逾期罚款：" + String.format("%.1f", fine) + "元";
            notificationService.notifyById(record.getUserId(), "还书成功", msg);
            logger.info("归还图书记录id={}, 罚款={}", recordId, fine);

            // 归还后检查是否有待处理预约
            checkPendingReservations(record.getBookId());
            return msg;
        }
        return "归还操作失败";
    }

    /** 续借 */
    public String renewBook(int recordId) {
        BorrowRecord record = borrowRecordDAO.findById(recordId);
        if (record == null) return "借阅记录不存在";
        if (!record.canRenew()) {
            if (record.getRenewed() == 1) return "该书已续借过一次，无法再次续借";
            if (record.isOverdue()) return "该书已逾期，请先归还再借";
            return "该书当前状态不允许续借";
        }

        if (borrowRecordDAO.renewBook(recordId)) {
            notificationService.notifyById(record.getUserId(), "续借成功",
                    "《" + record.getBookTitle() + "》续借成功，新的应还日期已延长14天");
            logger.info("续借记录id={}", recordId);
            return "续借成功，应还日期已延长14天";
        }
        return "续借操作失败";
    }

    /** 检查并处理预约：归还后若有库存，通知预约用户 */
    private void checkPendingReservations(int bookId) {
        Book book = bookService.getBookById(bookId);
        if (book != null && book.isAvailable() && reservationService != null) {
            reservationService.notifyReservedUsers(bookId);
        }
    }

    /** 获取所有借阅记录 */
    public List<BorrowRecord> getAllRecords() {
        borrowRecordDAO.updateOverdueStatus();
        return borrowRecordDAO.findAll();
    }

    /** 获取当前借阅 */
    public List<BorrowRecord> getCurrentBorrows() {
        borrowRecordDAO.updateOverdueStatus();
        return borrowRecordDAO.findCurrentBorrows();
    }

    /** 获取用户借阅历史 */
    public List<BorrowRecord> getUserHistory(int userId) {
        borrowRecordDAO.updateOverdueStatus();
        return borrowRecordDAO.findByUserId(userId);
    }

    /** 检查用户是否借过某书 */
    public boolean hasUserBorrowed(int userId, int bookId) {
        return borrowRecordDAO.hasUserBorrowedBook(userId, bookId);
    }

    /** 根据ID获取记录 */
    public BorrowRecord getRecordById(int id) {
        return borrowRecordDAO.findById(id);
    }

    /** 获取分类借阅统计 */
    public List<Object[]> getBorrowStatsByCategory() {
        return borrowRecordDAO.getBorrowStatsByCategory();
    }

    /** 获取热门图书统计 */
    public List<Object[]> getHotBookStats(int limit) {
        return borrowRecordDAO.getHotBookStats(limit);
    }
}
