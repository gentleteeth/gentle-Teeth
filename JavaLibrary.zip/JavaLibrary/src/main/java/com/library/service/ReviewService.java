package com.library.service;

import com.library.dao.ReviewDAO;
import com.library.model.Review;
import com.library.model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * 评论服务 —— 处理图书评分与评论
 */
public class ReviewService {
    private static final Logger logger = LogManager.getLogger(ReviewService.class);
    private final ReviewDAO reviewDAO = new ReviewDAO();
    private final BorrowService borrowService;

    public ReviewService(BorrowService borrowService) {
        this.borrowService = borrowService;
    }

    /** 添加评论（需验证用户借阅过该书） */
    public String addReview(User user, int bookId, int rating, String comment) {
        if (rating < 1 || rating > 5) return "评分必须在1-5之间";

        if (!borrowService.hasUserBorrowed(user.getId(), bookId)) {
            return "只有借阅过该书的用户才能评论";
        }

        if (reviewDAO.hasUserReviewed(user.getId(), bookId)) {
            return "您已评论过该书";
        }

        Review review = new Review();
        review.setUserId(user.getId());
        review.setBookId(bookId);
        review.setRating(rating);
        review.setComment(comment);

        if (reviewDAO.insert(review)) {
            logger.info("用户 {} 评论了图书id={}, 评分={}", user.getUsername(), bookId, rating);
            return "评论发表成功";
        }
        return "评论失败，请重试";
    }

    /** 删除评论 */
    public boolean deleteReview(int reviewId) {
        return reviewDAO.delete(reviewId);
    }

    /** 获取图书评论列表 */
    public List<Review> getBookReviews(int bookId) {
        return reviewDAO.findByBookId(bookId);
    }

    /** 获取图书平均评分 */
    public double getAverageRating(int bookId) {
        return reviewDAO.getAverageRating(bookId);
    }

    /** 获取用户评论 */
    public List<Review> getUserReviews(int userId) {
        return reviewDAO.findByUserId(userId);
    }
}
