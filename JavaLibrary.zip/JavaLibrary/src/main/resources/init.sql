-- 图书管理系统数据库初始化脚本
-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'member',
    email TEXT,
    phone TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 图书分类表
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT
);

-- 图书表
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    isbn TEXT UNIQUE,
    title TEXT NOT NULL,
    author TEXT,
    publisher TEXT,
    category_id INTEGER,
    publish_year INTEGER,
    total_copies INTEGER DEFAULT 1,
    available_copies INTEGER DEFAULT 1,
    location TEXT,
    description TEXT,
    cover_image TEXT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- 借阅记录表
CREATE TABLE IF NOT EXISTS borrow_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    book_id INTEGER NOT NULL,
    borrow_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    due_date DATETIME NOT NULL,
    return_date DATETIME,
    status TEXT DEFAULT 'borrowed',
    fine_amount REAL DEFAULT 0.0,
    renewed INTEGER DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

-- 图书预约表
CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    book_id INTEGER NOT NULL,
    reserve_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

-- 图书评论表
CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    book_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

-- ============ 测试数据 ============

-- 测试账号（首次登录后密码自动加密）
-- admin / admin123  |  librarian / lib123  |  reader / reader123  |  zhangsan / reader123  |  lisi / reader123
INSERT OR IGNORE INTO users (id, username, password, role, email, phone) VALUES
(1, 'admin', 'admin123', 'admin', 'admin@library.com', '13800000001'),
(2, 'librarian', 'lib123', 'librarian', 'lib@library.com', '13800000002'),
(3, 'reader', 'reader123', 'member', 'reader@example.com', '13800000003'),
(4, 'zhangsan', 'reader123', 'member', 'zhangsan@example.com', '13800000004'),
(5, 'lisi', 'reader123', 'member', 'lisi@example.com', '13800000005');

-- 图书分类
INSERT OR IGNORE INTO categories (id, name, description) VALUES
(1, '计算机科学', '计算机科学与技术相关图书'),
(2, '文学小说', '中外文学名著与小说'),
(3, '历史哲学', '历史与哲学类图书'),
(4, '自然科学', '数学、物理、化学等自然科学'),
(5, '经济管理', '经济学与管理学类图书'),
(6, '外语学习', '外语学习与教材'),
(7, '艺术设计', '艺术与设计类图书'),
(8, '医学健康', '医学与健康养生类图书');

-- 图书数据
INSERT OR IGNORE INTO books (id, isbn, title, author, publisher, category_id, publish_year, total_copies, available_copies, location, description) VALUES
(1, '978-7-111-11111-1', 'Java编程思想', 'Bruce Eckel', '机械工业出版社', 1, 2020, 5, 3, 'A区-1架-001', 'Java语言经典著作，全面讲解Java编程思想与最佳实践'),
(2, '978-7-111-22222-2', '算法导论', 'Thomas H. Cormen', '机械工业出版社', 1, 2019, 3, 2, 'A区-1架-002', '算法领域的经典教材'),
(3, '978-7-111-33333-3', '设计模式', 'GoF', '机械工业出版社', 1, 2018, 4, 4, 'A区-1架-003', '面向对象设计模式经典著作'),
(4, '978-7-302-44444-4', '数据库系统概论', '王珊', '高等教育出版社', 1, 2021, 3, 1, 'A区-2架-001', '数据库系统基础教材'),
(5, '978-7-302-55555-5', '深入理解Java虚拟机', '周志明', '机械工业出版社', 1, 2022, 4, 3, 'A区-2架-002', 'JVM深度解析'),
(6, '978-7-5321-66666-6', '红楼梦', '曹雪芹', '人民文学出版社', 2, 2015, 6, 5, 'B区-1架-001', '中国古典四大名著之首'),
(7, '978-7-5321-77777-7', '百年孤独', '加西亚·马尔克斯', '南海出版公司', 2, 2017, 3, 0, 'B区-1架-002', '魔幻现实主义代表作'),
(8, '978-7-5321-88888-8', '活着', '余华', '作家出版社', 2, 2018, 5, 2, 'B区-2架-001', '讲述人在极端环境下的生存故事'),
(9, '978-7-100-99999-9', '史记', '司马迁', '中华书局', 3, 2016, 3, 3, 'C区-1架-001', '中国第一部纪传体通史'),
(10, '978-7-100-00000-1', '西方哲学史', '罗素', '商务印书馆', 3, 2019, 2, 1, 'C区-1架-002', '西方哲学发展历程经典著作'),
(11, '978-7-03-11111-1', '高等数学', '同济大学', '高等教育出版社', 4, 2020, 5, 4, 'D区-1架-001', '理工科基础数学教材'),
(12, '978-7-03-22222-2', '时间简史', '霍金', '湖南科技出版社', 4, 2018, 3, 1, 'D区-1架-002', '宇宙学入门科普经典'),
(13, '978-7-300-33333-3', '经济学原理', '曼昆', '北京大学出版社', 5, 2021, 4, 2, 'E区-1架-001', '经济学入门经典教材'),
(14, '978-7-300-44444-4', '卓有成效的管理者', '德鲁克', '机械工业出版社', 5, 2019, 3, 3, 'E区-1架-002', '管理学经典著作'),
(15, '978-7-5600-55555-5', '新概念英语', '亚历山大', '外语教学与研究出版社', 6, 2020, 8, 6, 'F区-1架-001', '经典英语学习教材'),
(16, '978-7-5600-66666-6', '牛津高阶英汉双解词典', '牛津大学出版社', '商务印书馆', 6, 2021, 2, 1, 'F区-1架-002', '权威英语学习词典'),
(17, '978-7-5153-77777-7', '设计中的设计', '原研哉', '山东人民出版社', 7, 2017, 2, 2, 'G区-1架-001', '设计思维经典著作'),
(18, '978-7-5153-88888-8', '色彩构成', '约瑟夫·阿尔伯斯', '人民邮电出版社', 7, 2019, 2, 2, 'G区-1架-002', '色彩理论基础教材'),
(19, '978-7-117-99999-9', '黄帝内经', '佚名', '人民卫生出版社', 8, 2015, 2, 0, 'H区-1架-001', '中医经典著作'),
(20, '978-7-117-00000-1', '营养学', '塞泽尔', '清华大学出版社', 8, 2020, 2, 2, 'H区-1架-002', '现代营养学基础教材');

-- 借阅记录（部分已归还，部分借阅中，部分逾期）
INSERT OR IGNORE INTO borrow_records (id, user_id, book_id, borrow_date, due_date, return_date, status, fine_amount, renewed) VALUES
(1, 3, 1, '2026-06-01 10:00:00', '2026-06-15 10:00:00', '2026-06-10 14:30:00', 'returned', 0.0, 0),
(2, 3, 6, '2026-06-15 09:00:00', '2026-06-29 09:00:00', NULL, 'borrowed', 0.0, 0),
(3, 4, 2, '2026-06-10 11:00:00', '2026-06-24 11:00:00', '2026-06-28 16:00:00', 'returned', 0.4, 0),
(4, 4, 7, '2026-06-20 10:00:00', '2026-07-04 10:00:00', NULL, 'borrowed', 0.0, 0),
(5, 5, 11, '2026-06-05 14:00:00', '2026-06-19 14:00:00', '2026-06-20 09:00:00', 'returned', 0.1, 0),
(6, 5, 19, '2026-05-20 10:00:00', '2026-06-03 10:00:00', NULL, 'overdue', 2.7, 0);

-- 预约记录
INSERT OR IGNORE INTO reservations (id, user_id, book_id, reserve_date, status) VALUES
(1, 4, 7, '2026-06-25 10:00:00', 'pending'),
(2, 3, 19, '2026-06-28 09:00:00', 'pending');

-- 评论数据
INSERT OR IGNORE INTO reviews (id, user_id, book_id, rating, comment, created_at) VALUES
(1, 3, 1, 5, '非常好的Java入门书，讲解透彻', '2026-06-12 10:00:00'),
(2, 4, 2, 5, '算法经典，值得反复阅读', '2026-06-29 10:00:00'),
(3, 5, 11, 4, '高等数学教材，条理清晰', '2026-06-21 10:00:00'),
(4, 3, 6, 5, '中国文学巅峰之作', '2026-06-20 10:00:00');
